// Графики Chart.js. Данные для графиков считаются в filters.js из того же
// отфильтрованного набора, что и таблица, карта и KPI.

import { countBy, countStatuses, regionsByPotential } from './filters.js';
import { STATUS } from './data.js';

const COLORS = {
  client: '#7100e6',
  potential: '#ff4f12',
  unknown: '#737987',
  bars: '#7100e6',
  palette: ['#7100e6', '#c0188f', '#ff4f12', '#4d0fa3', '#e4672b', '#9d4edd', '#a3126e', '#6b6f85'],
};

let charts = null;
let canvases = null;

export function initCharts(canvasMap) {
  if (typeof window.Chart === 'undefined') {
    throw new Error('Библиотека Chart.js не загрузилась. Проверьте доступ к интернету.');
  }
  canvases = canvasMap;
  const Chart = window.Chart;
  Chart.defaults.font.family = '"Inter", "Segoe UI", system-ui, sans-serif';
  Chart.defaults.color = '#5b6074';
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    Chart.defaults.animation = false;
  }

  const barOptions = {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#eceef4' } },
      y: { grid: { display: false } },
    },
  };

  charts = {
    industry: new Chart(canvasMap.industry, {
      type: 'bar',
      data: { labels: [], datasets: [{ label: 'Компаний', data: [], backgroundColor: COLORS.bars, borderRadius: 4 }] },
      options: barOptions,
    }),
    status: new Chart(canvasMap.status, {
      type: 'doughnut',
      data: {
        labels: ['Действующий клиент (подтверждён)', 'Потенциальный клиент (подтверждён)', 'Статус не подтверждён'],
        datasets: [{ data: [0, 0, 0], backgroundColor: [COLORS.client, COLORS.potential, COLORS.unknown], borderColor: '#fff', borderWidth: 2 }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '60%',
        plugins: { legend: { position: 'bottom' } },
      },
    }),
    regions: new Chart(canvasMap.regions, {
      type: 'bar',
      data: { labels: [], datasets: [{ label: 'Потенциальных клиентов', data: [], backgroundColor: COLORS.potential, borderRadius: 4 }] },
      options: barOptions,
    }),
  };
}

function setEmpty(canvas, isEmpty) {
  const card = canvas.closest('.chart-card');
  if (!card) return;
  card.classList.toggle('is-empty', isEmpty);
  const note = card.querySelector('.chart-empty');
  if (note) note.hidden = !isEmpty;
}

export function updateCharts(companies) {
  if (!charts) return;

  const byIndustry = countBy(companies, 'industry');
  charts.industry.data.labels = byIndustry.map((x) => x.label);
  charts.industry.data.datasets[0].data = byIndustry.map((x) => x.count);
  charts.industry.update();
  setEmpty(canvases.industry, byIndustry.length === 0);
  canvases.industry.setAttribute(
    'aria-label',
    byIndustry.length
      ? `Компании по отраслям: ${byIndustry.map((x) => `${x.label} — ${x.count}`).join('; ')}`
      : 'Нет данных по отраслям'
  );

  const { clients, potential, unknown } = countStatuses(companies);
  charts.status.data.datasets[0].data = [clients, potential, unknown];
  charts.status.update();
  setEmpty(canvases.status, clients + potential + unknown === 0);
  canvases.status.setAttribute('aria-label', `Подтверждённых действующих клиентов: ${clients}; подтверждённых потенциальных клиентов: ${potential}; без подтверждённого статуса: ${unknown}`);

  const regions = regionsByPotential(companies).slice(0, 8);
  charts.regions.data.labels = regions.map((x) => x.region);
  charts.regions.data.datasets[0].data = regions.map((x) => x.count);
  charts.regions.update();
  setEmpty(canvases.regions, regions.length === 0);
  canvases.regions.setAttribute(
    'aria-label',
    regions.length
      ? `Потенциальные клиенты по регионам: ${regions.map((x) => `${x.region} — ${x.count}`).join('; ')}`
      : 'Нет потенциальных клиентов в выборке'
  );
}
