// Фильтрация, сортировка и расчёты. Чистые функции без DOM — единый источник
// бизнес-логики для карты, KPI, графиков, таблицы и рейтинга территорий.

import { STATUS } from './data.js';
import { normalizeText } from './utils.js';

export const DEFAULT_FILTERS = Object.freeze({
  region: '',
  industry: '',
  status: '',
  search: '',
  revenueMin: null,
  revenueMax: null,
  growthMin: null,
  growthMax: null,
});
export const UNKNOWN_STATUS = '__unknown__';

/** Веса демонстрационной модели оценки территорий (сумма = 1). */
export const SCORE_WEIGHTS = Object.freeze({ potential: 0.5, growth: 0.3, diversity: 0.2 });

export function parseNumberInput(value) {
  if (value === null || value === undefined) return null;
  const text = String(value).trim().replace(',', '.');
  if (text === '') return null;
  const n = Number(text);
  return Number.isFinite(n) ? n : null;
}

/** Возвращает текст ошибки, если диапазон задан неверно, иначе ''. */
export function validateFilters(f) {
  if (f.revenueMin !== null && f.revenueMax !== null && f.revenueMin > f.revenueMax) {
    return 'Выручка: минимум больше максимума.';
  }
  if (f.growthMin !== null && f.growthMax !== null && f.growthMin > f.growthMax) {
    return 'Темп роста: минимум больше максимума.';
  }
  return '';
}

export function applyFilters(companies, filters) {
  const f = { ...DEFAULT_FILTERS, ...filters };
  const query = normalizeText(f.search);
  return companies.filter((c) => {
    if (f.region && c.region !== f.region) return false;
    if (f.industry && c.industry !== f.industry) return false;
    if (f.status === UNKNOWN_STATUS && c.clientStatus != null) return false;
    if (f.status && f.status !== UNKNOWN_STATUS) {
      const isClientStatus = Object.values(STATUS).includes(f.status);
      if (isClientStatus ? c.clientStatus !== f.status : c.businessStatus !== f.status) return false;
    }
    if (query && !normalizeText(c.name).includes(query)) return false;
    if ((f.revenueMin !== null || f.revenueMax !== null) && !Number.isFinite(c.revenue)) return false;
    if ((f.growthMin !== null || f.growthMax !== null) && !Number.isFinite(c.growthRate)) return false;
    if (f.revenueMin !== null && c.revenue < f.revenueMin) return false;
    if (f.revenueMax !== null && c.revenue > f.revenueMax) return false;
    if (f.growthMin !== null && c.growthRate < f.growthMin) return false;
    if (f.growthMax !== null && c.growthRate > f.growthMax) return false;
    return true;
  });
}

const collator = new Intl.Collator('ru');

export function getFilterOptions(companies) {
  const uniq = (key) => [...new Set(companies.map((c) => c[key]).filter((value) => typeof value === 'string' && value.trim()))].sort(collator.compare);
  const statuses = [...new Set([
    ...companies.map((company) => company.businessStatus),
    ...companies.map((company) => company.clientStatus),
  ].filter((value) => typeof value === 'string' && value.trim()))].sort(collator.compare);
  if (companies.some((company) => company.clientStatus == null)) statuses.push(UNKNOWN_STATUS);
  return { regions: uniq('region'), industries: uniq('industry'), statuses };
}

const NUMERIC_KEYS = new Set(['revenue', 'growthRate']);

export function sortCompanies(companies, { key = 'name', dir = 'asc' } = {}) {
  const sign = dir === 'desc' ? -1 : 1;
  return [...companies].sort((a, b) => {
    if (NUMERIC_KEYS.has(key)) {
      const aKnown = Number.isFinite(a[key]);
      const bKnown = Number.isFinite(b[key]);
      if (aKnown !== bKnown) return aKnown ? -1 : 1;
    }
    const aValue = key === 'businessStatus' ? (a.businessStatus || a.clientStatus) : a[key];
    const bValue = key === 'businessStatus' ? (b.businessStatus || b.clientStatus) : b[key];
    const cmp = NUMERIC_KEYS.has(key) ? (a[key] ?? 0) - (b[key] ?? 0) : collator.compare(String(aValue ?? ''), String(bValue ?? ''));
    return cmp !== 0 ? sign * cmp : collator.compare(a.name, b.name);
  });
}

/** Количество компаний по значению поля, по убыванию. */
export function countBy(companies, key) {
  const map = new Map();
  for (const c of companies) map.set(c[key], (map.get(c[key]) || 0) + 1);
  return [...map.entries()]
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count || collator.compare(a.label, b.label));
}

export function countStatuses(companies) {
  let clients = 0;
  let potential = 0;
  let unknown = 0;
  for (const c of companies) {
    if (c.clientStatus === STATUS.CLIENT) clients += 1;
    else if (c.clientStatus === STATUS.POTENTIAL) potential += 1;
    else unknown += 1;
  }
  return { clients, potential, unknown };
}

/** Регионы с хотя бы одним потенциальным клиентом, по убыванию их числа. */
export function regionsByPotential(companies) {
  const map = new Map();
  for (const c of companies) {
    if (c.clientStatus === STATUS.POTENTIAL) map.set(c.region, (map.get(c.region) || 0) + 1);
  }
  return [...map.entries()]
    .map(([region, count]) => ({ region, count }))
    .sort((a, b) => b.count - a.count || collator.compare(a.region, b.region));
}

/**
 * Демонстрационная оценка территорий (условный индекс 0–100, не прогноз дохода).
 * Для каждого региона с потенциальными клиентами:
 *   потенциал  — число потенциальных компаний;
 *   рост       — средний темп роста потенциальных компаний (отрицательный считается как 0);
 *   разнообразие — число различных отраслей среди потенциальных компаний.
 * Каждый показатель делится на максимум среди регионов текущей выборки.
 * isOpportunity: потенциальных не меньше 2 и больше, чем действующих.
 * lowPresence: действующие клиенты составляют не более трети компаний региона.
 */
export function computeRegionOpportunities(companies) {
  const regions = new Map();
  for (const c of companies) {
    if (!regions.has(c.region)) {
      regions.set(c.region, { region: c.region, total: 0, clients: 0, potential: 0, growthSum: 0, growthCount: 0, industries: new Set() });
    }
    const r = regions.get(c.region);
    r.total += 1;
    if (c.clientStatus === STATUS.CLIENT) r.clients += 1;
    if (c.clientStatus === STATUS.POTENTIAL) {
      r.potential += 1;
      if (Number.isFinite(c.growthRate)) {
        r.growthSum += c.growthRate;
        r.growthCount += 1;
      }
      r.industries.add(c.industry);
    }
  }

  const rows = [...regions.values()]
    .filter((r) => r.potential > 0)
    .map((r) => ({
      region: r.region,
      total: r.total,
      clients: r.clients,
      potential: r.potential,
      avgGrowth: r.growthCount ? r.growthSum / r.growthCount : null,
      industries: r.industries.size,
    }));

  const maxP = Math.max(0, ...rows.map((r) => r.potential));
  const maxG = Math.max(0, ...rows.map((r) => Number.isFinite(r.avgGrowth) ? Math.max(0, r.avgGrowth) : 0));
  const maxD = Math.max(0, ...rows.map((r) => r.industries));

  return rows
    .map((r) => {
      const p = maxP ? r.potential / maxP : 0;
      const g = maxG && Number.isFinite(r.avgGrowth) ? Math.max(0, r.avgGrowth) / maxG : 0;
      const d = maxD ? r.industries / maxD : 0;
      const score = Math.round(100 * (SCORE_WEIGHTS.potential * p + SCORE_WEIGHTS.growth * g + SCORE_WEIGHTS.diversity * d));
      return {
        ...r,
        score,
        isOpportunity: r.potential >= 2 && r.potential > r.clients,
        lowPresence: r.total > 0 && r.clients / r.total <= 1 / 3,
      };
    })
    .sort((a, b) => b.score - a.score || b.potential - a.potential || collator.compare(a.region, b.region));
}

export function computeKpi(companies) {
  const { clients, potential, unknown } = countStatuses(companies);
  const territories = computeRegionOpportunities(companies).filter((r) => r.isOpportunity).length;
  return { total: companies.length, clients, potential, unknown, territories };
}
