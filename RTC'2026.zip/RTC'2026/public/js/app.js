// Точка входа: связывает состояние, данные, фильтры, карту, графики и интерфейс.

import { store } from './state.js';
import { CsvDataProvider, JsonDataProvider, OsmMapDataProvider } from './data.js';
import {
  DEFAULT_FILTERS, applyFilters, computeKpi, computeRegionOpportunities,
  getFilterOptions, sortCompanies, validateFilters,
} from './filters.js';
import * as ui from './ui.js';
import * as map from './map.js';
import * as analytics from './analytics.js';
import { downloadCsv } from './export.js';

let activeProvider = null;
let mapOk = false;
let chartsOk = false;
let lastFiltered = [];
const $ = (id) => document.getElementById(id);

function render(state) {
  ui.renderHeader(state);

  if (state.status === 'loading') {
    ui.renderLoading();
    return;
  }
  if (state.status === 'error') {
    ui.renderError();
    return;
  }

  // Один отфильтрованный набор — источник для карты, KPI, графиков, таблицы и рейтинга.
  const filtered = applyFilters(state.companies, state.filters);
  lastFiltered = filtered;

  ui.renderFilterHint(validateFilters(state.filters));
  ui.renderResultCount(filtered.length, state.companies.length);
  ui.renderKpi(computeKpi(filtered));
  ui.renderTable(sortCompanies(filtered, state.sort), state.sort);
  ui.renderOpportunities(computeRegionOpportunities(filtered));
  if (mapOk) map.updateMarkers(filtered);
  if (chartsOk) analytics.updateCharts(filtered);
}

function patchFilters(patch) {
  store.set((s) => ({ filters: { ...s.filters, ...patch } }));
}

function resetFilters() {
  ui.syncFilterInputs(DEFAULT_FILTERS);
  store.set({ filters: { ...DEFAULT_FILTERS } });
}

function toggleSort(key) {
  store.set((s) => ({
    sort: s.sort.key === key
      ? { key, dir: s.sort.dir === 'asc' ? 'desc' : 'asc' }
      : { key, dir: key === 'revenue' || key === 'growthRate' ? 'desc' : 'asc' },
  }));
}

function focusOnMap(id) {
  if (!mapOk) return;
  $('map-section').scrollIntoView({ block: 'start' });
  map.focusCompany(id);
}

function exportCsv() {
  if (store.get().status !== 'ready') {
    ui.showBanner('Данные ещё не загружены — экспортировать нечего.', { kind: 'warn', autoHide: 5000 });
    return;
  }
  if (!lastFiltered.length) {
    ui.showBanner('В текущей выборке нет компаний — экспортировать нечего. Измените фильтры.', { kind: 'warn', autoHide: 5000 });
    return;
  }
  downloadCsv(lastFiltered);
  ui.showBanner(`Экспортировано записей: ${lastFiltered.length}.`, { kind: 'info', autoHide: 4000 });
}

async function loadData(provider = activeProvider) {
  if (!provider) return;
  const previousState = store.get();
  activeProvider = provider;
  ui.hideBanner();
  $('sourceImportStatus').textContent = '';
  const isOsmRefresh = provider instanceof OsmMapDataProvider;
  $('loadOsmBtn').disabled = isOsmRefresh;
  if (isOsmRefresh) {
    $('osmStatus').textContent = provider.circle
      ? `Загрузка объектов в круге радиусом ${formatRadius(provider.circle.radius)}…`
      : 'Загрузка объектов OpenStreetMap…';
  }
  if (!isOsmRefresh || previousState.status !== 'ready') {
    store.set({ status: 'loading', error: null });
  }
  try {
    const { companies, meta, warnings } = await provider.load();
    ui.populateFilterOptions(getFilterOptions(companies));
    ui.syncFilterInputs(DEFAULT_FILTERS);
    store.set({ status: 'ready', companies, meta, warnings, filters: { ...DEFAULT_FILTERS } });
    $('sourceImportStatus').textContent = `Загружено записей: ${companies.length}.`;
    if (warnings.length) {
      $('sourceImportStatus').textContent += ` Предупреждения: ${warnings.length}.`;
    }
    $('osmStatus').textContent = isOsmRefresh
      ? provider.circle
        ? `OpenStreetMap: загружено объектов в круге радиусом ${formatRadius(provider.circle.radius)} — ${companies.length}. Статус клиентов не подтверждён.`
        : `OpenStreetMap: загружено объектов в видимой области — ${companies.length}. Статус клиентов не подтверждён.`
      : meta?.dataset === 'OpenStreetMap (сохранённый срез)'
        ? `Сохранённый срез OpenStreetMap: ${companies.length} объекта. Онлайн-обновление выполняется отдельно.`
        : 'Показан импортированный CSV-файл.';
    if (warnings.length) {
      ui.showBanner(`Данные загружены с предупреждениями (${warnings.length}). ${warnings[0]}`, { kind: 'warn' });
    }
  } catch (err) {
    if (isOsmRefresh) {
      if (previousState.status !== 'ready') {
        ui.populateFilterOptions({ regions: [], industries: [], statuses: [] });
        store.set({
          status: 'ready',
          error: null,
          companies: [],
          meta: { dataset: 'OpenStreetMap', isDemo: false },
          warnings: [],
          filters: { ...DEFAULT_FILTERS },
        });
      }
    } else {
      store.set({ status: 'error', error: err.message });
    }
    $('sourceImportStatus').textContent = err.message;
    if (isOsmRefresh && previousState.status === 'ready') {
      const message = `Не удалось обновить данные OSM. На карте оставлен последний загруженный набор (${previousState.companies.length} объектов).`;
      $('osmStatus').textContent = `${message} ${err.message}`;
      ui.showBanner(`${message} ${err.message}`, { kind: 'warn', actionLabel: 'Повторить', onAction: () => loadData(provider) });
    } else {
      ui.showBanner(err.message, { kind: 'error', actionLabel: 'Повторить', onAction: () => loadData(provider) });
      $('osmStatus').textContent = err.message;
    }
  } finally {
    $('loadOsmBtn').disabled = !map.getAreaSelection();
  }
}

function loadVisibleOsmData() {
  const viewport = map.getViewport();
  if (!viewport) {
    ui.showBanner('Карта недоступна — нельзя определить область загрузки.', { kind: 'error' });
    return;
  }
  loadData(new OsmMapDataProvider(viewport));
}

function fitOsmResults() {
  if (!map.fitCompanies(lastFiltered)) {
    ui.showBanner('В текущей выборке нет точек с координатами.', { kind: 'warn', autoHide: 5000 });
  }
}

function formatRadius(radius) {
  return radius >= 1000 ? `${String(radius / 1000).replace('.', ',')} км` : `${radius} м`;
}

function init() {
  ui.initNavigation();
  ui.renderMethodology();
  ui.bindFilters({ onPatch: patchFilters, onReset: resetFilters });
  ui.bindTable({ onSort: toggleSort, onFocusCompany: focusOnMap });
  $('exportBtn').addEventListener('click', exportCsv);
  $('fitOsmResultsBtn').addEventListener('click', fitOsmResults);
  $('selectOsmAreaBtn').addEventListener('click', () => {
    const selecting = $('selectOsmAreaBtn').dataset.selecting !== 'true';
    $('selectOsmAreaBtn').dataset.selecting = String(selecting);
    $('selectOsmAreaBtn').textContent = selecting ? 'Отменить выбор центра' : 'Выбрать круг на карте';
    map.setAreaSelectionMode(selecting);
    $('osmStatus').textContent = selecting
      ? `Щёлкните по карте, чтобы выбрать центр круга радиусом ${formatRadius(Number($('osmRadius').value))}.`
      : 'Выбор центра отменён.';
  });
  $('osmRadius').addEventListener('change', (event) => {
    const selection = map.setAreaRadius(Number(event.currentTarget.value));
    if (selection) {
      $('osmStatus').textContent = `Выбран круг радиусом ${formatRadius(selection.radius)}. Нажмите «Загрузить объекты в круг».`;
    }
  });
  $('clearOsmAreaBtn').addEventListener('click', () => {
    map.clearAreaSelection();
    $('loadOsmBtn').disabled = true;
    $('selectOsmAreaBtn').dataset.selecting = 'false';
    $('selectOsmAreaBtn').textContent = 'Выбрать круг на карте';
    map.setAreaSelectionMode(false);
    $('osmStatus').textContent = 'Область поиска сброшена. Выберите центр круга на карте.';
  });
  $('map').addEventListener('osm-area-selected', (event) => {
    const { center, radius } = event.detail;
    $('selectOsmAreaBtn').dataset.selecting = 'false';
    $('selectOsmAreaBtn').textContent = 'Выбрать другой центр';
    $('loadOsmBtn').disabled = false;
    $('osmStatus').textContent = `Круг радиусом ${formatRadius(radius)} выбран: ${center.latitude.toFixed(4)}, ${center.longitude.toFixed(4)}.`;
  });
  $('loadOsmBtn').addEventListener('click', () => {
    const selection = map.getAreaSelection();
    if (!selection) {
      ui.showBanner('Сначала выберите центр круга на карте.', { kind: 'warn' });
      return;
    }
    loadData(new OsmMapDataProvider(selection.bounds, { circle: selection }));
  });
  $('heatToggle').addEventListener('change', (event) => {
    if (!map.setHeatEnabled(event.currentTarget.checked)) {
      event.currentTarget.checked = false;
      event.currentTarget.disabled = true;
      $('osmStatus').textContent = 'Тепловой слой недоступен: библиотека не загрузилась.';
    }
  });
  $('csvFileInput').addEventListener('change', (event) => {
    const [file] = event.currentTarget.files;
    if (file) loadData(new CsvDataProvider(file));
    event.currentTarget.value = '';
  });

  const problems = [];
  try {
    map.initMap($('map'), $('mapMessage'));
    mapOk = true;
  } catch (err) {
    problems.push(err.message);
    map.showUnavailable('Карта недоступна: не загрузилась библиотека Leaflet. Таблица, показатели и фильтры работают.');
  }
  try {
    analytics.initCharts({
      industry: $('chartIndustry'),
      status: $('chartStatus'),
      regions: $('chartRegions'),
    });
    chartsOk = true;
  } catch (err) {
    problems.push(err.message);
  }

  store.subscribe(render);
  render(store.get());
  map.setAreaRadius(Number($('osmRadius').value));
  loadData(new JsonDataProvider()).then(() => loadVisibleOsmData());
  if (problems.length) ui.showBanner(problems.join(' '), { kind: 'warn' });
}

init();
