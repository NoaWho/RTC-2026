// Небольшие чистые утилиты форматирования. Не зависят от DOM.

const numberFormat = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 });
const intFormat = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });

export function formatInt(value) {
  return intFormat.format(value);
}

export function formatRevenue(value) {
  if (!Number.isFinite(value)) return '—';
  return `${numberFormat.format(value)} млн ₽`;
}

export function formatPercent(value) {
  if (!Number.isFinite(value)) return '—';
  const sign = value > 0 ? '+' : '';
  return `${sign}${numberFormat.format(value)} %`;
}

/** '2026-10-01' -> '01.10.2026'. Если формат неожиданный, возвращает исходную строку. */
export function formatDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso ?? ''));
  return m ? `${m[3]}.${m[2]}.${m[1]}` : String(iso ?? '—');
}

/** Нормализация строки для поиска: нижний регистр, ё -> е, обрезка пробелов. */
export function normalizeText(value) {
  return String(value ?? '').toLowerCase().replace(/ё/g, 'е').trim();
}
