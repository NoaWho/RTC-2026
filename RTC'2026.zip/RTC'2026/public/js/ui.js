// Интерфейс: навигация, фильтры, KPI, таблица, рейтинг территорий, баннеры.
// Бизнес-логика здесь не считается — модуль только отображает готовые данные.

import { getCompanyBusinessType, STATUS, hasCoords } from './data.js';
import { parseNumberInput, SCORE_WEIGHTS, UNKNOWN_STATUS } from './filters.js';
import { formatDate, formatInt, formatPercent, formatRevenue } from './utils.js';

const $ = (id) => document.getElementById(id);

/* ---------- Навигация ---------- */
export function initNavigation() {
  const toggle = $('navToggle');
  const sidebar = $('sidebar');
  const backdrop = $('backdrop');
  const legendDisclosure = $('legendDisclosure');
  const links = [...sidebar.querySelectorAll('a[data-section]')];
  let isMobile = window.matchMedia('(max-width: 640px)').matches;

  const setOpen = (open) => {
    sidebar.classList.toggle('is-open', open);
    backdrop.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
  };
  const setActive = (id) => {
    links.forEach((a) => {
      const active = a.dataset.section === id;
      a.classList.toggle('is-active', active);
      if (active) a.setAttribute('aria-current', 'true');
      else a.removeAttribute('aria-current');
    });
  };

  toggle.addEventListener('click', () => setOpen(!sidebar.classList.contains('is-open')));
  backdrop.addEventListener('click', () => setOpen(false));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && sidebar.classList.contains('is-open')) {
      setOpen(false);
      toggle.focus();
    }
  });
  links.forEach((a) => a.addEventListener('click', () => {
    setActive(a.dataset.section);
    setOpen(false);
  }));

  setActive('overview');
  const syncLegend = () => {
    const nextIsMobile = window.matchMedia('(max-width: 640px)').matches;
    if (nextIsMobile !== isMobile) {
      isMobile = nextIsMobile;
      legendDisclosure.open = !isMobile;
    }
  };
  legendDisclosure.open = !isMobile;
  window.addEventListener('resize', syncLegend);
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) setActive(entry.target.id);
      });
    }, { rootMargin: '-30% 0px -60% 0px' });
    links.forEach((a) => {
      const section = $(a.dataset.section);
      if (section) observer.observe(section);
    });
  }
}

/* ---------- Фильтры ---------- */
const FIELDS = [
  ['fSearch', 'search', 'text'],
  ['fRegion', 'region', 'select'],
  ['fIndustry', 'industry', 'select'],
  ['fStatus', 'status', 'select'],
  ['fRevMin', 'revenueMin', 'number'],
  ['fRevMax', 'revenueMax', 'number'],
  ['fGrowMin', 'growthMin', 'number'],
  ['fGrowMax', 'growthMax', 'number'],
];

function fillSelect(select, values) {
  const first = select.options[0];
  select.replaceChildren(first);
  values.forEach((v) => {
    const option = document.createElement('option');
    option.value = v;
    option.textContent = v;
    select.append(option);
  });
}

export function populateFilterOptions({ regions, industries, statuses = [] }) {
  fillSelect($('fRegion'), regions);
  fillSelect($('fIndustry'), industries);
  fillSelect($('fStatus'), statuses.filter((status) => status !== UNKNOWN_STATUS));
  if (statuses.includes(UNKNOWN_STATUS)) {
    const unknown = document.createElement('option');
    unknown.value = UNKNOWN_STATUS;
    unknown.textContent = 'Статус клиента не подтверждён';
    $('fStatus').append(unknown);
  }
}

export function bindFilters({ onPatch, onReset }) {
  $('filtersForm').addEventListener('submit', (e) => e.preventDefault());
  let timer;
  FIELDS.forEach(([id, key, type]) => {
    const input = $(id);
    const emit = () => onPatch({ [key]: type === 'number' ? parseNumberInput(input.value) : input.value });
    if (type === 'text') {
      input.addEventListener('input', () => {
        clearTimeout(timer);
        timer = setTimeout(emit, 150);
      });
    } else {
      input.addEventListener(type === 'select' ? 'change' : 'input', emit);
    }
  });
  $('resetBtn').addEventListener('click', onReset);
}

export function syncFilterInputs(filters) {
  FIELDS.forEach(([id, key]) => {
    const value = filters[key];
    $(id).value = value === null || value === undefined ? '' : String(value);
  });
}

export function renderFilterHint(message) {
  const hint = $('filterHint');
  hint.textContent = message;
  hint.hidden = !message;
}

export function renderResultCount(shown, total) {
  $('resultCount').textContent = `Найдено: ${formatInt(shown)} из ${formatInt(total)}`;
}

/* ---------- Шапка, баннер, состояния ---------- */
export function renderHeader({ status, meta, filters, companies }) {
  $('metaTerritory').textContent = filters.region || 'Все регионы';
  $('metaDate').textContent = meta && meta.dataDate ? formatDate(meta.dataDate) : '—';
  const pill = $('metaSource');
  pill.dataset.state = status;
  pill.textContent = status === 'ready'
    ? (meta?.isDemo ? 'Демо-набор' : (meta?.dataset || 'Локальный источник'))
    : status === 'error' ? 'Ошибка загрузки' : 'Загрузка…';
  $('main').setAttribute('aria-busy', String(status === 'loading'));
  if (status === 'ready') {
    $('dataMode').textContent = meta?.isDemo
      ? 'Демонстрационный, синтетический'
      : meta?.dataset === 'OpenStreetMap' ? 'Публичные данные OSM' : 'Локальные данные';
    $('dataSourceName').textContent = meta?.dataset || 'Источник в метаданных не указан';
    $('dataRecordCount').textContent = formatInt(companies?.length ?? 0);
    $('dataSetDate').textContent = meta?.dataDate ? formatDate(meta.dataDate) : 'Не указана';
    $('dataCheckedAt').textContent = meta?.checkedAt ? formatDate(meta.checkedAt) : 'Не указана';
  }
}

let bannerTimer;
export function showBanner(message, { kind = 'warn', actionLabel = '', onAction = null, autoHide = 0 } = {}) {
  const banner = $('banner');
  clearTimeout(bannerTimer);
  banner.dataset.kind = kind;
  banner.replaceChildren();
  const text = document.createElement('span');
  text.textContent = message;
  banner.append(text);
  if (actionLabel && onAction) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-secondary';
    btn.textContent = actionLabel;
    btn.addEventListener('click', onAction);
    banner.append(btn);
  }
  banner.hidden = false;
  if (autoHide) bannerTimer = setTimeout(hideBanner, autoHide);
}

export function hideBanner() {
  clearTimeout(bannerTimer);
  $('banner').hidden = true;
}

export function renderLoading() {
  ['kpiTotal', 'kpiClients', 'kpiPotential', 'kpiUnknown', 'kpiTerritories'].forEach((id) => { $(id).textContent = '…'; });
  const body = $('companiesBody');
  body.replaceChildren();
  const tr = document.createElement('tr');
  const td = document.createElement('td');
  td.colSpan = 8;
  td.className = 'loading-row';
  td.textContent = 'Загрузка данных…';
  tr.append(td);
  body.append(tr);
  $('tableEmpty').hidden = true;
  $('tableCount').textContent = '';
  $('resultCount').textContent = 'Найдено: —';
}

export function renderError() {
  ['kpiTotal', 'kpiClients', 'kpiPotential', 'kpiUnknown', 'kpiTerritories'].forEach((id) => { $(id).textContent = '—'; });
  $('companiesBody').replaceChildren();
  $('tableEmpty').hidden = true;
  $('oppList').replaceChildren();
  $('resultCount').textContent = 'Найдено: —';
}

/* ---------- KPI ---------- */
const share = (part, total) => (total ? `${Math.round((part / total) * 100)} % выборки` : 'нет данных в выборке');

export function renderKpi(kpi) {
  $('kpiTotal').textContent = formatInt(kpi.total);
  $('kpiClients').textContent = formatInt(kpi.clients);
  $('kpiPotential').textContent = formatInt(kpi.potential);
  $('kpiUnknown').textContent = formatInt(kpi.unknown);
  $('kpiTerritories').textContent = formatInt(kpi.territories);
  $('kpiClientsHint').textContent = share(kpi.clients, kpi.total);
  $('kpiPotentialHint').textContent = share(kpi.potential, kpi.total);
}

/* ---------- Таблица ---------- */
export function bindTable({ onSort, onFocusCompany }) {
  $('companiesTable').querySelector('thead').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-sort]');
    if (btn) onSort(btn.dataset.sort);
  });
  $('companiesBody').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-focus-id]');
    if (btn) {
      onFocusCompany(btn.dataset.focusId);
      return;
    }
    const detailsBtn = e.target.closest('[data-details-id]');
    if (detailsBtn) {
      const company = tableRows.find((row) => row.id === detailsBtn.dataset.detailsId);
      if (company) showCompanyDetails(company);
    }
  });
  $('closeCompanyDialog').addEventListener('click', () => $('companyDialog').close());
}

function cell(text, { label, className = '' } = {}) {
  const td = document.createElement('td');
  if (label) td.dataset.label = label;
  if (className) td.className = className;
  td.textContent = text;
  return td;
}

function businessBadge(businessType) {
  if (!businessType) return null;
  const span = document.createElement('span');
  span.className = 'badge badge-category';
  span.textContent = businessType;
  return span;
}

function statusBadge(status, isDemo) {
  const span = document.createElement('span');
  span.className = `badge ${status === STATUS.CLIENT ? 'badge-client' : status === STATUS.POTENTIAL ? 'badge-potential' : 'badge-unknown'}`;
  span.textContent = !status
    ? 'Клиентский статус не проверен'
    : isDemo
      ? `Демо: ${status}`
      : status;
  return span;
}

let tableRows = [];

function detailValue(label, value) {
  const wrap = document.createElement('div');
  const term = document.createElement('dt');
  term.textContent = label;
  const description = document.createElement('dd');
  description.textContent = value || 'Не указано';
  wrap.append(term, description);
  return wrap;
}

function safeHttpsUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' ? url.href : null;
  } catch {
    return null;
  }
}

function safeFnsUrl(value) {
  const safeUrl = safeHttpsUrl(value);
  if (!safeUrl) return null;
  const hostname = new URL(safeUrl).hostname;
  return ['nalog.ru', 'nalog.gov.ru', 'egrul.nalog.ru', 'rmsp.nalog.ru']
    .some((host) => hostname === host || hostname.endsWith(`.${host}`))
    ? safeUrl
    : null;
}

function showCompanyDetails(company) {
  const details = $('companyDetails');
  details.replaceChildren();
  const notice = document.createElement('p');
  notice.className = 'detail-notice';
  notice.textContent = company.dataSource === 'OpenStreetMap'
    ? 'Название и расположение взяты из OpenStreetMap и не подтверждают статус юридического лица, отношения с Ростелекомом или актуальность контактов.'
    : company.isDemo
    ? 'Демонстрационная запись. Статус, показатели и координаты не подтверждены и не относятся к реальному клиенту.'
    : 'Данные приведены из указанного источника; отсутствие отметки проверки не означает подтверждение.';
  const list = document.createElement('dl');
  list.className = 'detail-list';
  list.append(
    detailValue('Идентификатор', company.id),
    detailValue('ИНН', company.inn),
    detailValue('ОГРН / ОГРНИП', company.ogrn),
    detailValue('Организационно-правовая форма', company.legalForm),
    detailValue('Основной ОКВЭД', company.okved),
    detailValue('Руководитель', company.directorName),
    detailValue('Адрес регистрации по ФНС', company.registrationAddress),
    detailValue('Регион', company.region),
    detailValue('Населённый пункт', company.locality),
    detailValue('Адрес', company.address),
    detailValue('Отрасль', company.industry),
    detailValue('Тип объекта', getCompanyBusinessType(company)),
    detailValue('Статус отношений с Ростелекомом', company.clientStatus ? `${company.isDemo ? 'Условный (демо): ' : ''}${company.clientStatus}` : 'Не подтверждён'),
    detailValue('Проверка статуса', company.statusVerification),
    detailValue('Выручка, млн ₽', Number.isFinite(company.revenue) ? formatRevenue(company.revenue) : null),
    detailValue('Отчётный период', company.financialPeriod),
    detailValue('Темп роста', Number.isFinite(company.growthRate) ? formatPercent(company.growthRate) : null),
    detailValue('Оператор', company.operator),
    detailValue('Бренд', company.brand),
    detailValue('Телефон', company.phone),
    detailValue('Сайт', company.website),
    detailValue('Электронная почта', company.email),
    detailValue('Часы работы', company.openingHours),
    detailValue('Дополнительные теги OSM', typeof company.osmTags === 'object' ? JSON.stringify(company.osmTags) : company.osmTags),
    detailValue('Источник данных', company.dataSource),
    detailValue('URL источника', company.sourceUrl),
    detailValue('URL источника ФНС', company.fnsSourceUrl),
    detailValue('Проверено', company.checkedAt ? formatDate(company.checkedAt) : null),
    detailValue('Координаты', hasCoords(company) ? `${company.latitude}, ${company.longitude}` : null),
    detailValue('Источник координат', company.coordinateSource),
    detailValue('Описание', company.description),
  );
  details.append(notice, list);
  const sourceUrl = company.dataSource === 'OpenStreetMap' ? safeHttpsUrl(company.sourceUrl) : null;
  if (sourceUrl) {
    const sourceLink = document.createElement('a');
    sourceLink.href = sourceUrl;
    sourceLink.target = '_blank';
    sourceLink.rel = 'noopener noreferrer';
    sourceLink.textContent = 'Проверить объект в OpenStreetMap';
    details.append(sourceLink);
  }
  const fnsSourceUrl = safeFnsUrl(company.fnsSourceUrl);
  if (fnsSourceUrl) {
    const fnsLink = document.createElement('a');
    fnsLink.href = fnsSourceUrl;
    fnsLink.target = '_blank';
    fnsLink.rel = 'noopener noreferrer';
    fnsLink.textContent = 'Открыть источник данных ФНС';
    details.append(fnsLink);
  } else if (company.inn || company.ogrn) {
    const fnsLink = document.createElement('a');
    fnsLink.href = 'https://egrul.nalog.ru/index.html';
    fnsLink.target = '_blank';
    fnsLink.rel = 'noopener noreferrer';
    fnsLink.textContent = 'Проверить реквизиты в сервисе ФНС';
    details.append(fnsLink);
  }
  $('companyDialog').showModal();
}

export function renderTable(companies, sort) {
  tableRows = companies;
  document.querySelectorAll('#companiesTable thead th').forEach((th) => {
    th.setAttribute('aria-sort', th.dataset.key === sort.key ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none');
  });

  const body = $('companiesBody');
  body.replaceChildren();
  $('tableEmpty').hidden = companies.length > 0;
  $('companiesTable').hidden = companies.length === 0;
  $('tableCount').textContent = `Показано компаний: ${formatInt(companies.length)}`;

  const frag = document.createDocumentFragment();
  for (const c of companies) {
    const tr = document.createElement('tr');

    const nameTd = document.createElement('td');
    nameTd.className = 'cell-name';
    nameTd.dataset.label = 'Название';
    if (hasCoords(c)) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'link-btn';
      btn.dataset.focusId = c.id;
      btn.textContent = c.name;
      btn.title = 'Показать на карте';
      nameTd.append(btn);
    } else {
      nameTd.textContent = c.name;
      const note = document.createElement('span');
      note.className = 'no-coords';
      note.textContent = 'нет координат';
      nameTd.append(note);
    }

    const statusTd = document.createElement('td');
    statusTd.dataset.label = 'Тип предприятия / статус клиента';
    statusTd.className = 'status-cell';
    const typeBadge = businessBadge(getCompanyBusinessType(c));
    if (typeBadge) statusTd.append(typeBadge);
    statusTd.append(statusBadge(c.clientStatus, c.isDemo));
    const addressTd = document.createElement('td');
    addressTd.dataset.label = 'Адрес';
    if (c.address) {
      addressTd.textContent = c.address;
    } else if (c.dataSource === 'OpenStreetMap' && hasCoords(c)) {
      const addressBtn = document.createElement('button');
      addressBtn.type = 'button';
      addressBtn.className = 'link-btn';
      addressBtn.dataset.focusId = c.id;
      addressBtn.textContent = 'Уточнить на карте';
      addressTd.append(addressBtn);
    } else {
      addressTd.textContent = 'Не указан';
    }

    tr.append(
      nameTd,
      cell(c.region, { label: 'Регион' }),
      cell(c.industry, { label: 'Отрасль' }),
      statusTd,
      addressTd,
      cell(formatRevenue(c.revenue), { label: 'Выручка', className: 'num' }),
      cell(formatPercent(c.growthRate), { label: 'Темп роста', className: `num${c.growthRate < 0 ? ' growth-neg' : ''}` }),
    );
    const detailsTd = document.createElement('td');
    detailsTd.dataset.label = 'Данные';
    const detailsBtn = document.createElement('button');
    detailsBtn.type = 'button';
    detailsBtn.className = 'link-btn';
    detailsBtn.dataset.detailsId = c.id;
    detailsBtn.textContent = 'Подробнее';
    detailsTd.append(detailsBtn);
    tr.append(detailsTd);
    frag.append(tr);
  }
  body.append(frag);
}

/* ---------- Возможности развития ---------- */
export function renderMethodology() {
  const pct = (v) => `${Math.round(v * 100)} %`;
  $('oppMethod').textContent =
    `Как считается оценка. Условный индекс 0–100 для демонстрации, это не прогноз дохода и не вывод об отсутствии других поставщиков. ` +
    `Вклад: ${pct(SCORE_WEIGHTS.potential)} — число потенциальных компаний, ${pct(SCORE_WEIGHTS.growth)} — средний темп роста потенциальных компаний, ` +
    `${pct(SCORE_WEIGHTS.diversity)} — число отраслей среди них. Каждый показатель сравнивается с максимумом среди территорий текущей выборки. ` +
    `Метка «потенциальная возможность»: потенциальных клиентов не меньше двух и больше, чем действующих. ` +
    `Метка «низкое представленное клиентское присутствие»: действующие клиенты — не более трети компаний территории.`;
}

export function renderOpportunities(rows) {
  const list = $('oppList');
  list.replaceChildren();
  $('oppEmpty').hidden = rows.length > 0;

  rows.slice(0, 10).forEach((r, i) => {
    const li = document.createElement('li');
    li.className = 'opp-item';

    const rank = document.createElement('span');
    rank.className = 'opp-rank';
    rank.textContent = String(i + 1);

    const info = document.createElement('div');
    const name = document.createElement('div');
    name.className = 'opp-name';
    name.textContent = r.region;
    const meta = document.createElement('div');
    meta.className = 'opp-meta';
    meta.textContent =
      `Потенциальных: ${r.potential} · Действующих: ${r.clients} · ` +
      `Средний рост потенциальных: ${formatPercent(r.avgGrowth)} · Отраслей: ${r.industries}`;
    info.append(name, meta);
    if (r.isOpportunity || r.lowPresence) {
      const tags = document.createElement('div');
      tags.className = 'opp-tags';
      if (r.isOpportunity) {
        const t = document.createElement('span');
        t.className = 'tag';
        t.textContent = 'Потенциальная возможность';
        tags.append(t);
      }
      if (r.lowPresence) {
        const t = document.createElement('span');
        t.className = 'tag tag-low';
        t.textContent = 'Низкое представленное клиентское присутствие';
        tags.append(t);
      }
      info.append(tags);
    }

    const score = document.createElement('div');
    score.className = 'opp-score';
    const value = document.createElement('div');
    value.className = 'opp-score-value';
    value.textContent = String(r.score);
    const label = document.createElement('div');
    label.className = 'opp-score-label';
    label.textContent = 'условный индекс';
    const meter = document.createElement('div');
    meter.className = 'meter';
    meter.setAttribute('role', 'presentation');
    const bar = document.createElement('span');
    bar.style.width = `${r.score}%`;
    meter.append(bar);
    score.append(value, label, meter);

    li.append(rank, info, score);
    list.append(li);
  });
}
