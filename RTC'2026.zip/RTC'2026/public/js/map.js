// Карта: Leaflet + OpenStreetMap. Маркеры строятся из отфильтрованного набора.

import { getCompanyBusinessType, OSM_MIN_ZOOM, STATUS, hasCoords } from './data.js';
import { formatDate, formatRevenue, formatPercent } from './utils.js';

let map = null;
let layer = null;
let heatLayer = null;
let messageEl = null;
let heatEnabled = true;
let selectionMode = false;
let areaRadius = 500;
let areaCircle = null;
let areaCenterMarker = null;
const markersById = new Map();
const addressLookups = new Map();

function selectAreaCenter(center, container) {
  const L = window.L;
  if (!areaCircle) {
    areaCircle = L.circle(center, {
      radius: areaRadius,
      color: '#5b21b6',
      weight: 2,
      dashArray: '6 5',
      fillColor: '#7c3aed',
      fillOpacity: 0.13,
      interactive: false,
    }).addTo(map);
    areaCenterMarker = L.circleMarker(center, {
      radius: 4,
      color: '#fff',
      weight: 2,
      fillColor: '#5b21b6',
      fillOpacity: 1,
      interactive: false,
    }).addTo(map);
  } else {
    areaCircle.setLatLng(center);
    areaCircle.setRadius(areaRadius);
    areaCenterMarker.setLatLng(center);
  }
  selectionMode = false;
  map.dragging.enable();
  container.classList.remove('map-selecting');
  map.fitBounds(areaCircle.getBounds(), { padding: [24, 24], maxZoom: 17 });
  container.dispatchEvent(new CustomEvent('osm-area-selected', {
    detail: getAreaSelection(),
  }));
}

export function initMap(container, messageElement) {
  messageEl = messageElement;
  if (typeof window.L === 'undefined') {
    throw new Error('Библиотека Leaflet не загрузилась. Проверьте доступ к интернету.');
  }
  const L = window.L;
  map = L.map(container, { scrollWheelZoom: true }).setView([47.2357, 39.7015], 15);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',
  }).addTo(map);
  if (typeof L.heatLayer === 'function') {
    heatLayer = L.heatLayer([], {
      radius: 28,
      blur: 22,
      maxZoom: 17,
      gradient: { 0.2: '#9d4edd', 0.55: '#ff4f12', 0.85: '#ffe066', 1: '#ffffff' },
    }).addTo(map);
  }
  layer = L.featureGroup().addTo(map);
  map.on('click', (event) => {
    if (!selectionMode) return;
    selectAreaCenter(event.latlng, container);
  });

  if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(() => map.invalidateSize()).observe(container);
  }
  window.addEventListener('resize', () => map.invalidateSize());
}

export function clearAreaSelection() {
  if (!areaCircle || !map) return;
  map.removeLayer(areaCircle);
  if (areaCenterMarker) map.removeLayer(areaCenterMarker);
  areaCircle = null;
  areaCenterMarker = null;
}

export function isReady() {
  return map !== null;
}

export function fitCompanies(companies) {
  if (!map) return false;
  const points = companies.filter(hasCoords).map((company) => [company.latitude, company.longitude]);
  if (!points.length) return false;
  map.fitBounds(window.L.latLngBounds(points), { padding: [28, 28], maxZoom: 17 });
  return true;
}

export function getViewport() {
  if (!map) return null;
  const bounds = map.getBounds();
  return {
    south: bounds.getSouth(),
    west: bounds.getWest(),
    north: bounds.getNorth(),
    east: bounds.getEast(),
    zoom: map.getZoom(),
  };
}

export function setAreaSelectionMode(enabled) {
  if (!map) return false;
  selectionMode = Boolean(enabled);
  if (selectionMode) {
    map.dragging.disable();
    map.getContainer().classList.add('map-selecting');
  } else {
    map.dragging.enable();
    map.getContainer().classList.remove('map-selecting');
  }
  return true;
}

export function setAreaRadius(radiusMeters) {
  if (!Number.isFinite(radiusMeters) || radiusMeters <= 0) {
    throw new Error('Радиус поиска должен быть положительным числом.');
  }
  areaRadius = radiusMeters;
  if (areaCircle) {
    areaCircle.setRadius(areaRadius);
    map.fitBounds(areaCircle.getBounds(), { padding: [24, 24], maxZoom: 17 });
  }
  return getAreaSelection();
}

export function getAreaSelection() {
  if (!areaCircle) return null;
  const center = areaCircle.getLatLng();
  const latitudeOffset = areaRadius / 111320;
  const longitudeOffset = areaRadius / (111320 * Math.cos((center.lat * Math.PI) / 180));
  return {
    center: { latitude: center.lat, longitude: center.lng },
    radius: areaRadius,
    bounds: {
      south: center.lat - latitudeOffset,
      west: center.lng - longitudeOffset,
      north: center.lat + latitudeOffset,
      east: center.lng + longitudeOffset,
      zoom: OSM_MIN_ZOOM,
    },
  };
}

export function setHeatEnabled(enabled) {
  heatEnabled = Boolean(enabled);
  if (!map || !heatLayer) return false;
  if (heatEnabled && !map.hasLayer(heatLayer)) heatLayer.addTo(map);
  if (!heatEnabled && map.hasLayer(heatLayer)) map.removeLayer(heatLayer);
  return true;
}

function showMessage(text) {
  if (!messageEl) return;
  messageEl.textContent = text;
  messageEl.hidden = !text;
}

function row(label, value) {
  const frag = document.createDocumentFragment();
  const dt = document.createElement('dt');
  dt.textContent = label;
  const dd = document.createElement('dd');
  dd.textContent = value;
  frag.append(dt, dd);
  return frag;
}

function appendPopupRow(list, label, value) {
  if (value === null || value === undefined || value === '') return;
  list.append(row(label, String(value)));
}

function safeFnsUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && ['nalog.ru', 'nalog.gov.ru', 'egrul.nalog.ru', 'rmsp.nalog.ru']
      .some((host) => url.hostname === host || url.hostname.endsWith(`.${host}`))
      ? url.href
      : null;
  } catch {
    return null;
  }
}

function appendPopupLink(root, href, text) {
  const link = document.createElement('a');
  link.href = href;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  link.textContent = text;
  root.append(link);
}

/** Карточка компании строится через DOM и textContent — без вставки HTML из данных. */
export function buildPopup(company) {
  const root = document.createElement('div');
  root.className = 'popup';
  const title = document.createElement('div');
  title.className = 'popup-title';
  title.textContent = company.name;
  const demo = document.createElement('div');
  demo.className = 'popup-demo';
  demo.textContent = company.isDemo
    ? 'Демонстрационная запись · статус не подтверждён'
    : `Источник: ${company.dataSource || 'не указан'}`;
  const dl = document.createElement('dl');
  const businessType = getCompanyBusinessType(company);
  const addressRow = document.createDocumentFragment();
  const addressLabel = document.createElement('dt');
  addressLabel.textContent = 'Адрес';
  const addressValue = document.createElement('dd');
  addressValue.className = 'popup-address';
  addressValue.textContent = company.address || (company.dataSource === 'OpenStreetMap'
    ? 'Уточняется по картографическим данным…'
    : 'Не указан');
  addressRow.append(addressLabel, addressValue);
  appendPopupRow(dl, 'Тип объекта', businessType);
  dl.append(addressRow);
  appendPopupRow(dl, 'Город', company.locality);
  appendPopupRow(dl, 'ИНН', company.inn);
  appendPopupRow(dl, 'ОГРН / ОГРНИП', company.ogrn);
  appendPopupRow(dl, 'Организационно-правовая форма', company.legalForm);
  appendPopupRow(dl, 'Основной ОКВЭД', company.okved);
  appendPopupRow(dl, 'Руководитель', company.directorName);
  appendPopupRow(dl, 'Адрес регистрации по ФНС', company.registrationAddress);
  appendPopupRow(dl, 'Статус клиента', company.clientStatus
    ? `${company.isDemo ? 'Условный (демо): ' : ''}${company.clientStatus}`
    : 'Не подтверждён');
  appendPopupRow(dl, 'Источник подтверждения статуса', company.statusVerification);
  appendPopupRow(dl, 'Выручка', Number.isFinite(company.revenue) ? formatRevenue(company.revenue) : null);
  appendPopupRow(dl, 'Отчётный период', company.financialPeriod);
  appendPopupRow(dl, 'Темп роста', Number.isFinite(company.growthRate) ? formatPercent(company.growthRate) : null);
  appendPopupRow(dl, 'Телефон', company.phone);
  appendPopupRow(dl, 'Сайт', company.website);
  appendPopupRow(dl, 'Электронная почта', company.email);
  appendPopupRow(dl, 'Часы работы', company.openingHours);
  appendPopupRow(dl, 'Оператор', company.operator);
  appendPopupRow(dl, 'Бренд', company.brand);
  appendPopupRow(dl, 'Описание', company.description);
  root.append(title, demo, dl);
  const hasFnsData = [
    company.inn,
    company.ogrn,
    company.legalForm,
    company.okved,
    company.directorName,
    company.registrationAddress,
  ].some(Boolean);
  const fnsSourceUrl = safeFnsUrl(company.fnsSourceUrl);
  if (hasFnsData) {
    const source = document.createElement('div');
    source.className = 'popup-source';
    source.textContent = fnsSourceUrl
      ? 'Источник регистрационных данных: ФНС'
      : 'Регистрационные данные приведены в загруженном наборе; ссылка на запись ФНС не указана.';
    root.append(source);
  } else if (company.dataSource === 'OpenStreetMap') {
    const source = document.createElement('div');
    source.className = 'popup-source';
    source.textContent = 'Данные ФНС не сопоставлены: в картографическом источнике нет ИНН/ОГРН.';
    root.append(source);
  }
  if (fnsSourceUrl) {
    appendPopupLink(root, fnsSourceUrl, 'Открыть источник данных ФНС');
  } else if (hasFnsData || company.dataSource === 'OpenStreetMap') {
    appendPopupLink(root, 'https://egrul.nalog.ru/index.html', 'Проверить сведения в сервисе ФНС');
  }
  if (company.sourceUrl) {
    try {
      const url = new URL(company.sourceUrl);
      if (url.protocol === 'https:') {
        appendPopupLink(root, url.href, 'Открыть объект в OpenStreetMap');
      }
    } catch {
      // Invalid source URLs are not rendered as links.
    }
  }
  return root;
}

async function resolvePopupAddress(company, target) {
  const key = `${company.latitude},${company.longitude}`;
  if (!addressLookups.has(key)) {
    addressLookups.set(key, fetch(
      `https://photon.komoot.io/reverse?lat=${encodeURIComponent(company.latitude)}&lon=${encodeURIComponent(company.longitude)}`,
      { signal: AbortSignal.timeout(8000) },
    ).then(async (response) => {
      if (!response.ok) throw new Error(`Photon ответил ${response.status}.`);
      const result = await response.json();
      const properties = result.features?.[0]?.properties;
      if (!properties) return null;
      return [
        [properties.street, properties.housenumber].filter(Boolean).join(', '),
        properties.district,
        properties.city || properties.town || properties.village,
      ].filter(Boolean).join(', ') || null;
    }).catch((error) => {
      addressLookups.delete(key);
      throw error;
    }));
  }
  try {
    const address = await addressLookups.get(key);
    target.textContent = address
      ? `Ориентировочно: ${address} · Photon`
      : 'Адрес не найден в OpenStreetMap и Photon.';
  } catch {
    target.textContent = 'Не удалось уточнить адрес через Photon.';
  }
}

const BUSINESS_ICON_PATHS = Object.freeze({
    supermarket: '<path d="M4 9h16l-1 11H5L4 9Z"/><path d="m7 9 2-5m8 5-2-5M8 13v3m4-3v3m4-3v3"/>',
    groceries: '<path d="M5 10h14l-1 10H6L5 10Z"/><path d="M8 10a4 4 0 0 1 8 0M12 13v4"/>',
    bakery: '<path d="M4 13c0-2 1.5-3 3-3 1-3 3-4 5-4s4 1 5 4c1.5 0 3 1 3 3v4H4v-4Z"/><path d="M9 12v2m4-3v3m3-2v2"/>',
    clothes: '<path d="M8 5 12 8l4-3 4 3-3 3v9H7v-9L4 8l4-3Z"/><path d="M10 6a2 2 0 0 0 4 0"/>',
    pharmacy: '<path d="M12 4v16M4 12h16"/>',
    electronics: '<rect x="5" y="4" width="14" height="16" rx="2"/><path d="M8 7h8m-8 3h8m-8 3h4m1 4h2"/>',
    food: '<path d="M5 10h14l-1 10H6L5 10Z"/><path d="M8 10a4 4 0 0 1 8 0M12 4v2m-5-1 1 2m8-2-1 2"/>',
    health: '<path d="M12 4v16M4 12h16"/>',
    bank: '<path d="m3 9 9-5 9 5H3Zm2 2v6m5-6v6m4-6v6m5-6v6M3 20h18"/>',
    automotive: '<path d="m5 11 2-5h10l2 5 2 2v5h-2v-2H5v2H3v-5l2-2Z"/><path d="M7 11h10M7 14h.01M17 14h.01"/>',
    office: '<path d="M5 20V5h14v15M9 9h2m2 0h2m-6 4h2m2 0h2m-6 7v-3h4v3"/>',
    factory: '<path d="M3 20V9l6 3V8l6 4V5h6v15H3Z"/><path d="M17 8h1m-1 4h1m-1 4h1M7 16h1m4 0h1"/>',
    craft: '<path d="m14 7 3-3 3 3-3 3"/><path d="m4 20 9-9m-2-2 3 3m-8 4 3 3"/>',
    service: '<path d="M4 11h16l-1 9H5l-1-9Z"/><path d="M6 11V7h12v4m-9 3v2m6-2v2"/>',
    shop: '<path d="M4 10h16l-1 10H5L4 10Z"/><path d="m5 10 2-5h10l2 5M9 14v3m6-3v3"/>',
    business: '<path d="M4 20V8h16v12M8 8V5h8v3m-8 5h2m3 0h2m-7 4h2m3 0h2"/>',
});

function makeIcon(company) {
  const knownIcon = Object.hasOwn(BUSINESS_ICON_PATHS, company.businessIcon);
  const icon = knownIcon
    ? BUSINESS_ICON_PATHS[company.businessIcon]
    : '<path d="M4 20V8h16v12M8 8V5h8v3m-8 7h2m4 0h2"/>';
  const cls = knownIcon
    ? `map-pin--${company.businessIcon}`
    : company.clientStatus === STATUS.CLIENT
      ? 'map-pin--client'
      : company.clientStatus === STATUS.POTENTIAL ? 'map-pin--potential' : 'map-pin--unknown';
  return window.L.divIcon({
    className: 'pin-wrap',
    html: `<span class="map-pin ${cls}"><svg viewBox="0 0 24 24" aria-hidden="true">${icon}</svg></span>`,
    iconSize: [32, 38],
    iconAnchor: [16, 34],
    popupAnchor: [0, -31],
  });
}

export function updateMarkers(companies) {
  if (!map) return;
  layer.clearLayers();
  markersById.clear();

  const withCoords = companies.filter(hasCoords);
  if (heatLayer) {
    heatLayer.setLatLngs(withCoords.map((company) => [company.latitude, company.longitude, 0.7]));
    setHeatEnabled(heatEnabled);
  }
  for (const c of withCoords) {
    const marker = window.L.marker([c.latitude, c.longitude], {
      icon: makeIcon(c),
      title: `${c.name} — ${getCompanyBusinessType(c)}`,
      alt: c.name,
      keyboard: true,
    });
    const popup = buildPopup(c);
    marker.bindPopup(popup, { maxWidth: 340, maxHeight: 520 });
    marker.on('click', (event) => {
      if (!selectionMode) return;
      window.L.DomEvent.stopPropagation(event.originalEvent);
      selectAreaCenter(event.latlng, map.getContainer());
    });
    marker.on('popupopen', () => {
      if (!c.address && c.dataSource === 'OpenStreetMap') {
        resolvePopupAddress(c, popup.querySelector('.popup-address'));
      }
    });
    marker.addTo(layer);
    markersById.set(c.id, marker);
  }

  if (!companies.length) {
    showMessage('В загруженном наборе нет объектов для отображения. Загрузите объекты для текущей области карты.');
    return;
  }
  if (!withCoords.length) {
    showMessage('У компаний в текущей выборке нет координат — показать их на карте нельзя.');
    return;
  }
  showMessage('');
}

/** Центрирует карту на компании и открывает карточку. Возвращает false, если координат нет. */
export function focusCompany(id) {
  const marker = markersById.get(id);
  if (!map || !marker) return false;
  map.setView(marker.getLatLng(), Math.max(map.getZoom(), 9));
  marker.openPopup();
  return true;
}

export function showUnavailable(text) {
  showMessage(text);
}
