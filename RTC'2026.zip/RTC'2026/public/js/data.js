// Загрузка и проверка данных. Модуль не использует DOM и не имеет побочных эффектов
// при импорте, поэтому его можно тестировать в Node.

export const STATUS = Object.freeze({
  CLIENT: 'Действующий клиент',
  POTENTIAL: 'Потенциальный клиент',
});
export const STATUS_VALUES = Object.freeze(Object.values(STATUS));

export function hasCoords(company) {
  return Number.isFinite(company.latitude) && Number.isFinite(company.longitude);
}

const isText = (v) => typeof v === 'string' && v.trim() !== '';
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

/** Возвращает массив текстов ошибок; пустой массив — запись корректна. */
export function validateCompany(rec) {
  if (!rec || typeof rec !== 'object' || Array.isArray(rec)) {
    return ['запись не является объектом'];
  }
  const errors = [];
  if (!isText(rec.id)) errors.push('нет id');
  if (!isText(rec.name)) errors.push('нет названия');
  if (rec.region !== null && rec.region !== undefined && !isText(rec.region)) errors.push('регион должен быть текстом или отсутствовать');
  if (rec.industry !== null && rec.industry !== undefined && !isText(rec.industry)) errors.push('отрасль должна быть текстом или отсутствовать');
  if (rec.inn !== null && rec.inn !== undefined && !/^\d{10}(?:\d{2})?$/.test(String(rec.inn))) {
    errors.push('ИНН должен содержать 10 или 12 цифр либо отсутствовать');
  }
  if (rec.ogrn !== null && rec.ogrn !== undefined && !/^(?:\d{13}|\d{15})$/.test(String(rec.ogrn))) {
    errors.push('ОГРН/ОГРНИП должен содержать 13 или 15 цифр либо отсутствовать');
  }
  if (rec.clientStatus !== null && rec.clientStatus !== undefined && !STATUS_VALUES.includes(rec.clientStatus)) {
    errors.push(`неизвестный статус «${rec.clientStatus}»`);
  }
  if (rec.revenue !== null && rec.revenue !== undefined && (!isNum(rec.revenue) || rec.revenue < 0)) {
    errors.push('выручка должна быть неотрицательным числом или отсутствовать');
  }
  if (rec.growthRate !== null && rec.growthRate !== undefined && (!isNum(rec.growthRate) || rec.growthRate < -100)) {
    errors.push('темп роста должен быть числом не меньше -100 или отсутствовать');
  }
  if (rec.description !== null && rec.description !== undefined && typeof rec.description !== 'string') errors.push('описание должно быть текстом');

  const noLat = rec.latitude === null || rec.latitude === undefined;
  const noLng = rec.longitude === null || rec.longitude === undefined;
  if (noLat !== noLng) {
    errors.push('координаты заданы не полностью');
  } else if (!noLat) {
    if (!isNum(rec.latitude) || rec.latitude < -90 || rec.latitude > 90) errors.push('широта вне диапазона -90…90');
    if (!isNum(rec.longitude) || rec.longitude < -180 || rec.longitude > 180) errors.push('долгота вне диапазона -180…180');
  }
  return errors;
}

/**
 * Проверяет файл данных целиком.
 * Некорректные записи пропускаются и попадают в warnings.
 * Если структура неверна или не осталось ни одной корректной записи — бросает Error.
 */
export function validateDataset(raw) {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.companies)) {
    throw new Error('Неверная структура данных: ожидался объект с массивом «companies».');
  }
  const seen = new Set();
  const companies = [];
  const warnings = [];

  raw.companies.forEach((rec, index) => {
    const errors = validateCompany(rec);
    if (!errors.length && seen.has(rec.id)) errors.push(`повторяющийся id «${rec.id}»`);
    if (errors.length) {
      const label = rec && rec.id ? ` (${rec.id})` : '';
      warnings.push(`Запись №${index + 1}${label} пропущена: ${errors.join('; ')}.`);
      return;
    }
    seen.add(rec.id);
    companies.push({
      ...rec,
      region: rec.region ?? null,
      industry: rec.industry ?? null,
      locality: rec.locality ?? null,
      inn: rec.inn ?? null,
      ogrn: rec.ogrn ?? null,
      legalForm: rec.legalForm ?? null,
      okved: rec.okved ?? null,
      directorName: rec.directorName ?? null,
      registrationAddress: rec.registrationAddress ?? null,
      fnsSourceUrl: rec.fnsSourceUrl ?? null,
      clientStatus: rec.clientStatus ?? null,
      revenue: rec.revenue ?? null,
      growthRate: rec.growthRate ?? null,
      latitude: rec.latitude ?? null,
      longitude: rec.longitude ?? null,
      description: rec.description ?? '',
      isDemo: rec.isDemo ?? (raw.meta?.isDemo === true),
      dataSource: rec.dataSource ?? raw.meta?.dataset ?? null,
      sourceUrl: rec.sourceUrl ?? raw.meta?.sourceUrl ?? null,
      checkedAt: rec.checkedAt ?? raw.meta?.checkedAt ?? null,
      financialPeriod: rec.financialPeriod ?? raw.meta?.financialPeriod ?? null,
      coordinateSource: rec.coordinateSource ?? raw.meta?.coordinateSource ?? null,
      statusVerification: rec.statusVerification ?? null,
    });
  });

  if (!companies.length) throw new Error('В данных нет ни одной корректной записи.');

  return {
    companies,
    meta: { ...(raw.meta || {}), totalRecords: raw.companies.length },
    warnings,
  };
}

/**
 * Абстракция источника данных; реализации читают JSON, CSV или OpenStreetMap.
 */
export class DataProvider {
  /** @returns {Promise<{companies: object[], meta: object, warnings: string[]}>} */
  async load() {
    throw new Error('DataProvider.load() не реализован');
  }
}

export class JsonDataProvider extends DataProvider {
  constructor(url = 'data/osm-cache.json') {
    super();
    this.url = url;
  }

  async load() {
    let response;
    try {
      response = await fetch(this.url, { cache: 'no-cache' });
    } catch (err) {
      throw new Error(
        'Не удалось загрузить файл данных. Запустите приложение командой npm start.'
      );
    }
    if (!response.ok) {
      throw new Error(`Не удалось загрузить данные: сервер ответил ${response.status}.`);
    }
    let raw;
    try {
      raw = await response.json();
    } catch (err) {
      throw new Error('Файл данных повреждён: это не корректный JSON.');
    }
    return validateDataset(raw);
  }
}

function detectDelimiter(header) {
  let quoted = false;
  let semicolons = 0;
  let commas = 0;
  for (let index = 0; index < header.length; index += 1) {
    if (header[index] === '"' && header[index + 1] === '"' && quoted) index += 1;
    else if (header[index] === '"') quoted = !quoted;
    else if (!quoted && header[index] === ';') semicolons += 1;
    else if (!quoted && header[index] === ',') commas += 1;
  }
  return semicolons >= commas ? ';' : ',';
}

export function parseCsv(text, delimiter = null) {
  const source = String(text ?? '').replace(/^\uFEFF/, '');
  const separator = delimiter || detectDelimiter(source.split(/\r?\n/, 1)[0] || '');
  const rows = [];
  let row = [];
  let value = '';
  let quoted = false;

  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quoted && char === '"' && source[index + 1] === '"') {
      value += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (!quoted && char === separator) {
      row.push(value);
      value = '';
    } else if (!quoted && (char === '\n' || char === '\r')) {
      if (char === '\r' && source[index + 1] === '\n') index += 1;
      row.push(value);
      if (row.some((cell) => cell !== '')) rows.push(row);
      row = [];
      value = '';
    } else {
      value += char;
    }
  }
  if (quoted) throw new Error('CSV содержит незакрытую кавычку.');
  row.push(value);
  if (row.some((cell) => cell !== '')) rows.push(row);
  return rows;
}

const normalizeHeader = (value) => String(value ?? '').toLowerCase().replace(/ё/g, 'е').replace(/[^a-zа-я0-9]/g, '');

function parseImportedNumber(value) {
  if (value === null || value === undefined || String(value).trim() === '') return null;
  const parsed = Number(String(value).replace(/[\s\u00a0]/g, '').replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : null;
}

function truthyImport(value) {
  return ['да', 'yes', 'true', '1'].includes(normalizeHeader(value));
}

export class CsvDataProvider extends DataProvider {
  constructor(file) {
    super();
    this.file = file;
  }

  async load() {
    const rows = parseCsv(await this.file.text());
    if (rows.length < 2) throw new Error('CSV пуст или содержит только заголовки.');
    const headers = rows[0].map(normalizeHeader);
    const findColumn = (...names) => headers.findIndex((header) => names.includes(header));
    const cols = {
      id: findColumn('id', 'ид', 'идентификатор', 'инн', 'огрн'),
      inn: findColumn('инн'),
      ogrn: findColumn('огрн', 'огрнип'),
      legalForm: findColumn('организационноправоваяформа', 'правоваяформа'),
      okved: findColumn('оквэд', 'основнойоквэд', 'кодоквэд'),
      directorName: findColumn('руководитель', 'фиоруководителя', 'фамилияимяотчестворуководителя'),
      registrationAddress: findColumn('адресрегистрации', 'юридическийадрес', 'адресместонахождения'),
      fnsSourceUrl: findColumn('ссылкафнс', 'urlфнс', 'ссылкаисточникафнс'),
      name: findColumn('name', 'название', 'наименование', 'наименованиекомпании', 'наименованиоюридическоголица'),
      region: findColumn('region', 'регион', 'субъектрф', 'субъектроссийскойфедерации'),
      industry: findColumn('industry', 'отрасль', 'основнойоквэд', 'оквэд'),
      businessStatus: findColumn('типобъектапоosm'),
      businessCategory: findColumn('категорияosm'),
      businessType: findColumn('типпредприятия'),
      locality: findColumn('населенныйпункт', 'город', 'населенныйпунктместонахождения'),
      address: findColumn('адрес'),
      status: findColumn('status', 'статус', 'статусклиента'),
      statusVerification: findColumn('проверкастатуса', 'источникподтверждениястатуса'),
      demo: findColumn('демонстрационныеданные', 'демо'),
      revenue: findColumn('выручка', 'выручкамлн', 'выручкамлнр'),
      growthRate: findColumn('темпроста', 'темпростапроцентов', 'рост'),
      latitude: findColumn('широта', 'latitude'),
      longitude: findColumn('долгота', 'longitude'),
      description: findColumn('описание', 'description'),
      operator: findColumn('оператор'),
      brand: findColumn('бренд'),
      phone: findColumn('телефон'),
      website: findColumn('сайт'),
      email: findColumn('электроннаяпочта', 'email'),
      openingHours: findColumn('часыработы'),
      osmTags: findColumn('дополнительныетегиosm'),
      dataSource: findColumn('источникданных', 'источник'),
      sourceUrl: findColumn('urlисточника', 'ссылкаисточника'),
      checkedAt: findColumn('проверено', 'датапроверки'),
      financialPeriod: findColumn('отчетныйпериод', 'периодпоказателей'),
      coordinateSource: findColumn('источниккоординат'),
    };
    if (cols.id < 0 || cols.name < 0) throw new Error('В CSV нужны столбцы идентификатора (ID/ИНН/ОГРН) и названия компании.');

    const importWarnings = [];
    const records = rows.slice(1).map((cells, index) => {
      const get = (key) => {
        if (cols[key] < 0) return null;
        const value = (cells[cols[key]] ?? '').trim();
        return value || null;
      };
      const demo = truthyImport(get('demo'));
      const candidateStatus = get('status');
      const verifiedStatus = Boolean(get('statusVerification'));
      const status = STATUS_VALUES.includes(candidateStatus) && (demo || verifiedStatus) ? candidateStatus : null;
      if (candidateStatus && !demo && !STATUS_VALUES.includes(candidateStatus)) {
        importWarnings.push(`Строка ${index + 2}: неизвестный статус клиента не принят.`);
      } else if (candidateStatus && !demo && !verifiedStatus) {
        importWarnings.push(`Строка ${index + 2}: статус клиента не принят — не указан источник проверки.`);
      }
      return {
        id: get('id'),
        name: get('name'),
        region: get('region'),
        industry: get('industry'),
        businessStatus: get('businessStatus'),
        businessCategory: get('businessCategory'),
        businessType: get('businessType'),
        locality: get('locality'),
        inn: get('inn')?.replace(/\D/g, '') || null,
        ogrn: get('ogrn')?.replace(/\D/g, '') || null,
        legalForm: get('legalForm'),
        okved: get('okved'),
        directorName: get('directorName'),
        registrationAddress: get('registrationAddress'),
        fnsSourceUrl: get('fnsSourceUrl'),
        address: get('address'),
        clientStatus: status,
        revenue: parseImportedNumber(get('revenue')),
        growthRate: parseImportedNumber(get('growthRate')),
        latitude: parseImportedNumber(get('latitude')),
        longitude: parseImportedNumber(get('longitude')),
        description: get('description') || '',
        operator: get('operator'),
        brand: get('brand'),
        phone: get('phone'),
        website: get('website'),
        email: get('email'),
        openingHours: get('openingHours'),
        osmTags: get('osmTags'),
        isDemo: demo,
        dataSource: get('dataSource') || `Импорт CSV: ${this.file.name}`,
        sourceUrl: get('sourceUrl'),
        checkedAt: get('checkedAt'),
        financialPeriod: get('financialPeriod'),
        coordinateSource: get('coordinateSource'),
        statusVerification: verifiedStatus ? get('statusVerification') : null,
      };
    });
    const importedDemo = records.length > 0 && records.every((record) => record.isDemo);
    const result = validateDataset({
      meta: { dataset: `Импорт CSV: ${this.file.name}`, isDemo: importedDemo, dataDate: null },
      companies: records,
    });
    return { ...result, warnings: [...importWarnings, ...result.warnings] };
  }
}

export const OSM_MIN_ZOOM = 15;
const OSM_MAX_RESULTS = 2500;

function validateOsmBounds(bounds) {
  if (!bounds || !Number.isFinite(bounds.zoom)) {
    throw new Error('Не удалось определить масштаб карты.');
  }
  const { south, west, north, east } = bounds;
  const numbers = [south, west, north, east];
  if (!numbers.every(Number.isFinite)
    || south < -90 || north > 90 || west < -180 || east > 180
    || south >= north || west >= east) {
    throw new Error('Не удалось определить границы видимой области карты.');
  }
  if (bounds.zoom < OSM_MIN_ZOOM) {
    throw new Error(`Приблизьте карту до масштаба ${OSM_MIN_ZOOM} или ближе, чтобы загрузить объекты.`);
  }
  if (north - south > 0.15 || east - west > 0.25) {
    throw new Error('Область поиска слишком большая. Приблизьте карту и загрузите данные для меньшей области.');
  }

}

export function buildOsmMapUrl(bounds) {
  validateOsmBounds(bounds);
  const { south, west, north, east } = bounds;
  const box = [west, south, east, north].join(',');
  return `https://api.openstreetmap.org/api/0.6/map?bbox=${box}`;
}

export function splitOsmBounds(bounds, maxSpan = 0.01) {
  validateOsmBounds(bounds);
  const latitudeSteps = Math.ceil((bounds.north - bounds.south) / maxSpan);
  const longitudeSteps = Math.ceil((bounds.east - bounds.west) / maxSpan);
  const tiles = [];
  for (let row = 0; row < latitudeSteps; row += 1) {
    const south = bounds.south + ((bounds.north - bounds.south) * row) / latitudeSteps;
    const north = bounds.south + ((bounds.north - bounds.south) * (row + 1)) / latitudeSteps;
    for (let column = 0; column < longitudeSteps; column += 1) {
      const west = bounds.west + ((bounds.east - bounds.west) * column) / longitudeSteps;
      const east = bounds.west + ((bounds.east - bounds.west) * (column + 1)) / longitudeSteps;
      tiles.push({ south, west, north, east, zoom: bounds.zoom });
    }
  }
  return tiles;
}

const BUSINESS_CATEGORIES = Object.freeze({
  office: 'Офис / организация',
  shop: 'Торговля',
  craft: 'Мастерская / ремесло',
  industrial: 'Производство',
  amenity: 'Сервис / общепит',
});

const BUSINESS_AMENITIES = new Set([
  'bank', 'bar', 'cafe', 'car_repair', 'car_wash', 'clinic', 'dentist', 'doctors',
  'fast_food', 'fuel', 'hospital', 'pharmacy', 'pub', 'restaurant', 'veterinary',
]);

const SPECIFIC_SHOP_TYPES = new Set([
  'supermarket', 'convenience', 'bakery', 'clothes', 'department_store', 'mall',
  'chemist', 'pharmacy', 'electronics', 'hardware', 'furniture', 'shoes', 'books', 'kiosk',
]);

const BUSINESS_TYPE_LABELS = Object.freeze({
  supermarket: 'Супермаркет',
  convenience: 'Продуктовый магазин',
  bakery: 'Пекарня',
  clothes: 'Магазин одежды',
  department_store: 'Универмаг',
  mall: 'Торговый центр',
  chemist: 'Аптека',
  pharmacy: 'Аптека',
  electronics: 'Магазин электроники',
  hardware: 'Хозяйственный магазин',
  furniture: 'Мебельный магазин',
  shoes: 'Обувной магазин',
  books: 'Книжный магазин',
  kiosk: 'Киоск',
  cafe: 'Кафе',
  restaurant: 'Ресторан',
  fast_food: 'Быстрое питание',
  bar: 'Бар',
  pub: 'Паб',
  bank: 'Банк',
  fuel: 'Автозаправка',
  car_repair: 'Автосервис',
  car_wash: 'Автомойка',
  clinic: 'Клиника',
  hospital: 'Больница',
  doctors: 'Медицинский кабинет',
  dentist: 'Стоматология',
  veterinary: 'Ветеринарная клиника',
  company: 'Офис компании',
  government: 'Государственная организация',
  estate_agent: 'Недвижимость',
  tea: 'Магазин чая',
  confectionery: 'Кондитерская',
  variety_store: 'Универсальный магазин',
  greengrocer: 'Овощной магазин',
  butcher: 'Мясной магазин',
  seafood: 'Магазин морепродуктов',
  florist: 'Цветочный магазин',
  gift: 'Магазин подарков',
  optician: 'Оптика',
  mobile_phone: 'Магазин мобильных телефонов',
  computer: 'Компьютерный магазин',
  car: 'Автомагазин',
  bicycle: 'Веломагазин',
  toys: 'Магазин игрушек',
  laundry: 'Прачечная',
  dry_cleaning: 'Химчистка',
  hairdresser: 'Парикмахерская',
  beauty: 'Салон красоты',
  travel_agency: 'Туристическое агентство',
  lawyer: 'Юридическая компания',
  accountant: 'Бухгалтерская компания',
  insurance: 'Страховая компания',
  advertising_agency: 'Рекламное агентство',
  architect: 'Архитектурное бюро',
  consulting: 'Консалтинговая компания',
  carpenter: 'Столярная мастерская',
  electrician: 'Электромонтажная мастерская',
  plumber: 'Сантехническая мастерская',
  tailor: 'Ателье',
  photographer: 'Фотостудия',
  metal_construction: 'Металлоконструкции',
  warehouse: 'Склад',
  factory: 'Завод',
  manufacture: 'Производство',
  administrative: 'Административный офис',
  association: 'Общественная организация',
  educational_institution: 'Образовательное учреждение',
  ngo: 'Некоммерческая организация',
  religious: 'Религиозная организация',
  research: 'Научная организация',
  logistics: 'Логистическая компания',
});

const BUSINESS_CATEGORY_FALLBACKS = Object.freeze({
  office: 'Офис / организация',
  shop: 'Магазин',
  craft: 'Мастерская',
  industrial: 'Производственный объект',
  amenity: 'Объект обслуживания',
});

export function getRussianBusinessType(category, value, fallback) {
  if (isText(value) && BUSINESS_TYPE_LABELS[value.toLowerCase()]) {
    return BUSINESS_TYPE_LABELS[value.toLowerCase()];
  }
  if (isText(value) && /[а-яё]/i.test(value)) return value;
  if (isText(fallback) && /[а-яё]/i.test(fallback)) return fallback;
  return BUSINESS_CATEGORY_FALLBACKS[category] || 'Тип объекта не указан';
}

export function getCompanyBusinessType(company) {
  const tags = company?.osmTags && typeof company.osmTags === 'object' ? company.osmTags : {};
  const category = company?.businessCategory
    || ['office', 'industrial', 'craft'].find((key) => tags[key])
    || (SPECIFIC_SHOP_TYPES.has(tags.shop) ? 'shop' : null)
    || (BUSINESS_AMENITIES.has(tags.amenity) ? 'amenity' : null)
    || (tags.shop ? 'shop' : null)
    || (tags.amenity ? 'amenity' : null);
  const value = company?.businessType || (category ? tags[category] : null);
  return getRussianBusinessType(category, value, company?.businessStatus);
}

function getBusinessIcon(category, value) {
  const type = value?.toLowerCase();
  if (category === 'shop') {
    if (['supermarket', 'department_store', 'mall'].includes(type)) return 'supermarket';
    if (['bakery', 'confectionery'].includes(type)) return 'bakery';
    if (['clothes', 'shoes', 'fashion'].includes(type)) return 'clothes';
    if (['chemist', 'pharmacy'].includes(type)) return 'pharmacy';
    if (type === 'electronics') return 'electronics';
    if (type === 'convenience') return 'groceries';
    return 'shop';
  }
  if (category === 'amenity') {
    if (['cafe', 'bar', 'pub', 'restaurant', 'fast_food'].includes(type)) return 'food';
    if (['pharmacy', 'clinic', 'hospital', 'doctors', 'dentist', 'veterinary'].includes(type)) return 'health';
    if (type === 'bank') return 'bank';
    if (['car_repair', 'car_wash', 'fuel'].includes(type)) return 'automotive';
    return 'service';
  }
  if (category === 'office') return 'office';
  if (category === 'industrial') return 'factory';
  if (category === 'craft') return 'craft';
  return 'business';
}

export function normalizeOsmElements(elements) {
  const seen = new Set();
  const companies = [];
  for (const element of elements) {
    const tags = element.tags || {};
    const latitude = Number.isFinite(element.lat) ? element.lat : element.center?.lat;
    const longitude = Number.isFinite(element.lon) ? element.lon : element.center?.lon;
    const shopHasSpecificBusinessType = SPECIFIC_SHOP_TYPES.has(tags.shop);
    const categoryKey = ['office', 'industrial', 'craft'].find((key) => tags[key])
      || (shopHasSpecificBusinessType ? 'shop' : null)
      || (BUSINESS_AMENITIES.has(tags.amenity) ? 'amenity' : null)
      || (tags.shop ? 'shop' : null);
    if (categoryKey === 'amenity' && !BUSINESS_AMENITIES.has(tags.amenity)) continue;
    if (!categoryKey) continue;
    const categoryValue = categoryKey ? tags[categoryKey] : null;
    const businessType = getRussianBusinessType(categoryKey, categoryValue);
    const category = `${BUSINESS_CATEGORIES[categoryKey]} · ${businessType}`;
    if (!isText(tags.name) || !Number.isFinite(latitude) || !Number.isFinite(longitude)) continue;

    const type = element.type && element.id ? `${element.type}-${element.id}` : null;
    if (!type || seen.has(type)) continue;
    seen.add(type);
    const street = tags['addr:street'];
    const houseNumber = tags['addr:housenumber'];
    const city = tags['addr:city'] || tags['addr:town'] || tags['addr:village'];
    const address = [street && [street, houseNumber].filter(Boolean).join(', '), tags['addr:postcode'], city]
      .filter(Boolean)
      .join(', ') || null;
    companies.push({
      id: `osm-${type}`,
      name: tags.name.trim(),
      region: tags['addr:state'] || tags['addr:province'] || null,
      industry: category || 'Категория не указана',
      businessStatus: BUSINESS_CATEGORIES[categoryKey],
      businessCategory: categoryKey,
      businessType,
      businessIcon: getBusinessIcon(categoryKey, categoryValue),
      locality: city || null,
      address,
      clientStatus: null,
      revenue: null,
      growthRate: null,
      latitude,
      longitude,
      description: tags.description || `Объект OpenStreetMap${category ? `: ${category}` : ''}.`,
      operator: tags.operator || null,
      brand: tags.brand || null,
      phone: tags['contact:phone'] || tags.phone || null,
      website: tags['contact:website'] || tags.website || null,
      email: tags['contact:email'] || tags.email || null,
      openingHours: tags.opening_hours || null,
      osmTags: tags,
      isDemo: false,
      dataSource: 'OpenStreetMap',
      sourceUrl: `https://www.openstreetmap.org/${element.type}/${element.id}`,
      checkedAt: element.timestamp || null,
      financialPeriod: null,
      coordinateSource: 'OpenStreetMap',
      statusVerification: null,
    });
  }
  return companies;
}

export function isWithinOsmCircle(company, circle) {
  const radians = Math.PI / 180;
  const latitudeDelta = (company.latitude - circle.center.latitude) * radians;
  const longitudeDelta = (company.longitude - circle.center.longitude) * radians;
  const centerLatitude = circle.center.latitude * radians;
  const latitude = company.latitude * radians;
  const haversine = Math.sin(latitudeDelta / 2) ** 2
    + Math.cos(centerLatitude) * Math.cos(latitude) * Math.sin(longitudeDelta / 2) ** 2;
  const normalized = Math.min(1, Math.max(0, haversine));
  const distance = 6371000 * 2 * Math.atan2(Math.sqrt(normalized), Math.sqrt(1 - normalized));
  return distance <= circle.radius;
}

function parseOsmMapXml(xmlText, parseXml) {
  const document = parseXml(xmlText);
  if (!document || document.querySelector('parsererror')) {
    throw new Error('OpenStreetMap вернул повреждённый XML.');
  }
  const elements = [...document.querySelectorAll('node, way')];
  const nodes = new Map();
  const ways = [];
  const readTags = (element) => Object.fromEntries(
    [...element.querySelectorAll(':scope > tag')].map((tag) => [tag.getAttribute('k'), tag.getAttribute('v')]),
  );
  for (const element of elements) {
    if (element.tagName === 'node') {
      nodes.set(element.getAttribute('id'), {
        type: 'node',
        id: element.getAttribute('id'),
        lat: Number(element.getAttribute('lat')),
        lon: Number(element.getAttribute('lon')),
        timestamp: element.getAttribute('timestamp'),
        tags: readTags(element),
      });
    } else {
      ways.push(element);
    }
  }

  const normalized = [...nodes.values()];
  for (const way of ways) {
    const points = [...way.querySelectorAll(':scope > nd')]
      .map((nd) => nodes.get(nd.getAttribute('ref')))
      .filter(Boolean);
    if (!points.length) continue;
    normalized.push({
      type: 'way',
      id: way.getAttribute('id'),
      lat: points.reduce((sum, point) => sum + point.lat, 0) / points.length,
      lon: points.reduce((sum, point) => sum + point.lon, 0) / points.length,
      timestamp: way.getAttribute('timestamp'),
      tags: readTags(way),
    });
  }
  return normalized;
}

export class OsmMapDataProvider extends DataProvider {
  constructor(bounds, {
    fetchImpl = (...args) => globalThis.fetch(...args),
    parseXml = (text) => new DOMParser().parseFromString(text, 'application/xml'),
    circle = null,
  } = {}) {
    super();
    this.bounds = bounds;
    this.fetchImpl = fetchImpl;
    this.parseXml = parseXml;
    this.circle = circle;
  }

  async load() {
    if (typeof this.fetchImpl !== 'function') {
      throw new Error('Загрузка OpenStreetMap недоступна в этом браузере.');
    }
    const companies = [];
    const seen = new Set();
    let totalRecords = 0;

    const loadTile = async (bounds, depth = 0) => {
      if (companies.length === OSM_MAX_RESULTS) return;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 30000);
      let response;
      try {
        response = await this.fetchImpl(buildOsmMapUrl(bounds), {
          signal: controller.signal,
          headers: { Accept: 'application/xml' },
        });
      } catch (error) {
        if (error.name === 'AbortError') {
          throw new Error('Время ожидания ответа OpenStreetMap истекло. Сохранённые данные карты остаются доступными.');
        }
        throw new Error(`Не удалось загрузить OpenStreetMap: ${error.message}`);
      } finally {
        clearTimeout(timeout);
      }
      if (!response.ok) {
        const detail = await response.text();
        if (response.status === 400 && /too many nodes/i.test(detail) && depth < 8) {
          const latitudeSpan = bounds.north - bounds.south;
          const longitudeSpan = bounds.east - bounds.west;
          if (Math.max(latitudeSpan, longitudeSpan) > 0.00015) {
            const splitLatitude = latitudeSpan >= longitudeSpan;
            const midpoint = splitLatitude
              ? (bounds.south + bounds.north) / 2
              : (bounds.west + bounds.east) / 2;
            const halves = splitLatitude
              ? [
                { ...bounds, north: midpoint },
                { ...bounds, south: midpoint },
              ]
              : [
                { ...bounds, east: midpoint },
                { ...bounds, west: midpoint },
              ];
            for (const half of halves) {
              await loadTile(half, depth + 1);
              if (companies.length === OSM_MAX_RESULTS) break;
            }
            return;
          }
        }
        const message = detail.trim().slice(0, 180);
        throw new Error(`OpenStreetMap ответил ${response.status}${message ? `: ${message}` : ''}`);
      }
      const elements = parseOsmMapXml(await response.text(), this.parseXml);
      totalRecords += elements.length;
      for (const company of normalizeOsmElements(elements)) {
        if (this.circle && !isWithinOsmCircle(company, this.circle)) continue;
        if (!seen.has(company.id)) {
          seen.add(company.id);
          companies.push(company);
          if (companies.length === OSM_MAX_RESULTS) return;
        }
      }
    };

    for (const tile of splitOsmBounds(this.bounds)) {
      await loadTile(tile);
      if (companies.length === OSM_MAX_RESULTS) break;
    }
    return {
      companies,
      meta: {
        dataset: 'OpenStreetMap',
        isDemo: false,
        dataDate: null,
        checkedAt: new Date().toISOString(),
        notice: 'Только именованные картографические объекты в видимой области; это не полный реестр предприятий.',
        licence: 'Open Database License (ODbL)',
        totalRecords,
        selectedArea: this.circle ? {
          center: this.circle.center,
          radius: this.circle.radius,
        } : null,
      },
      warnings: [],
    };
  }
}

export function createDefaultProvider() {
  return new JsonDataProvider();
}
