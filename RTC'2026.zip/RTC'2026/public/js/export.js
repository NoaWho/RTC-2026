// Безопасный CSV-экспорт текущей отфильтрованной выборки.
// Разделитель «;» и десятичная запятая — для корректного открытия в русской локали Excel.

import { hasCoords } from './data.js';

export const CSV_DELIMITER = ';';
const BOM = '\uFEFF';

export const CSV_COLUMNS = [
  ['ID', (c) => c.id],
  ['ИНН', (c) => c.inn],
  ['ОГРН / ОГРНИП', (c) => c.ogrn],
  ['Организационно-правовая форма', (c) => c.legalForm],
  ['Основной ОКВЭД', (c) => c.okved],
  ['Руководитель', (c) => c.directorName],
  ['Адрес регистрации по ФНС', (c) => c.registrationAddress],
  ['URL источника ФНС', (c) => c.fnsSourceUrl],
  ['Название', (c) => c.name],
  ['Населённый пункт', (c) => c.locality],
  ['Регион', (c) => c.region],
  ['Адрес', (c) => c.address],
  ['Отрасль', (c) => c.industry],
  ['Тип объекта по OSM', (c) => c.businessStatus],
  ['Категория OSM', (c) => c.businessCategory],
  ['Тип предприятия', (c) => c.businessType],
  ['Статус клиента', (c) => c.clientStatus],
  ['Выручка, млн ₽', (c) => c.revenue],
  ['Темп роста, %', (c) => c.growthRate],
  ['Широта', (c) => (hasCoords(c) ? c.latitude : '')],
  ['Долгота', (c) => (hasCoords(c) ? c.longitude : '')],
  ['Описание', (c) => c.description],
  ['Оператор', (c) => c.operator],
  ['Бренд', (c) => c.brand],
  ['Телефон', (c) => c.phone],
  ['Сайт', (c) => c.website],
  ['Электронная почта', (c) => c.email],
  ['Часы работы', (c) => c.openingHours],
  ['Дополнительные теги OSM', (c) => c.osmTags ? JSON.stringify(c.osmTags) : ''],
  ['Источник данных', (c) => c.dataSource],
  ['URL источника', (c) => c.sourceUrl],
  ['Проверено', (c) => c.checkedAt],
  ['Отчётный период', (c) => c.financialPeriod],
  ['Источник координат', (c) => c.coordinateSource],
  ['Проверка статуса', (c) => c.statusVerification],
  ['Демонстрационные данные', (c) => c.isDemo ? 'Да' : 'Нет'],
];

/**
 * Защита от CSV-инъекций: текст, начинающийся с = + - @ (в том числе после пробелов)
 * либо с таба/возврата каретки, получает впереди апостроф. Числа выводятся как есть.
 */
export function sanitizeCell(value) {
  if (value === null || value === undefined) return '';
  if (typeof value === 'number') return Number.isFinite(value) ? String(value).replace('.', ',') : '';
  const text = String(value);
  if (/^\s*[=+\-@]/.test(text) || /^[\t\r]/.test(text)) return `'${text}`;
  return text;
}

export function escapeCsvField(text, delimiter = CSV_DELIMITER) {
  if (text.includes('"') || text.includes(delimiter) || /[\r\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

/** Собирает CSV (с BOM для кириллицы и переводами строк CRLF). */
export function buildCsv(companies) {
  const header = CSV_COLUMNS.map(([title]) => escapeCsvField(title)).join(CSV_DELIMITER);
  const lines = companies.map((c) =>
    CSV_COLUMNS.map(([, getter]) => escapeCsvField(sanitizeCell(getter(c)))).join(CSV_DELIMITER)
  );
  return BOM + [header, ...lines].join('\r\n') + '\r\n';
}

export function csvFileName(count, date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  const stamp = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  return `radar4promote_${stamp}_${count}-kompanij.csv`;
}

/** Запускает скачивание файла в браузере. */
export function downloadCsv(companies) {
  const blob = new Blob([buildCsv(companies)], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = csvFileName(companies.length);
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
