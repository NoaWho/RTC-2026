const logoutButton = document.getElementById('logoutBtn');

function requireLogin() {
  window.location.replace('/login.html');
}

async function checkSession() {
  try {
    const response = await fetch('/api/auth/status', { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) return requireLogin();
    const result = await response.json();
    if (!result.authenticated) requireLogin();
  } catch {
    requireLogin();
  }
}

logoutButton?.addEventListener('click', async () => {
  logoutButton.disabled = true;
  try {
    const response = await fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    });
    if (!response.ok) throw new Error('Сервер не подтвердил выход.');
    requireLogin();
  } catch (error) {
    logoutButton.disabled = false;
    window.alert(`Не удалось завершить сеанс: ${error.message}`);
  }
});

checkSession();
window.setInterval(checkSession, 60_000);
window.addEventListener('focus', checkSession);
