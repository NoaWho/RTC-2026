// Единое состояние приложения: простое хранилище с подпиской.

import { DEFAULT_FILTERS } from './filters.js';

export function createStore(initial) {
  let state = initial;
  const subscribers = new Set();
  return {
    get: () => state,
    /** patch — объект или функция (state) => объект; изменения объединяются с текущим состоянием. */
    set(patch) {
      const next = typeof patch === 'function' ? patch(state) : patch;
      state = { ...state, ...next };
      subscribers.forEach((fn) => fn(state));
    },
    subscribe(fn) {
      subscribers.add(fn);
      return () => subscribers.delete(fn);
    },
  };
}

export const store = createStore({
  status: 'loading', // 'loading' | 'ready' | 'error'
  error: null,
  warnings: [],
  meta: null,
  companies: [],
  filters: { ...DEFAULT_FILTERS },
  sort: { key: 'name', dir: 'asc' },
});
