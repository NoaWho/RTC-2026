const loginForm = document.getElementById('loginForm');
const verifyForm = document.getElementById('verifyForm');
const mfaStep = document.getElementById('mfaStep');
const setupInstructions = document.getElementById('setupInstructions');
const authMessage = document.getElementById('authMessage');
const passwordInput = document.getElementById('password');

function showMessage(message, kind = '') {
  authMessage.textContent = message;
  authMessage.dataset.kind = kind;
}

async function postJson(path, body) {
  const response = await fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    cache: 'no-store',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Не удалось выполнить запрос.');
  return result;
}

async function checkExistingSession() {
  try {
    const response = await fetch('/api/auth/status', { credentials: 'same-origin', cache: 'no-store' });
    if (!response.ok) throw new Error('Проверка авторизации недоступна.');
    const { authenticated } = await response.json();
    if (authenticated) window.location.replace('/');
  } catch (error) {
    showMessage(error.message, 'error');
  }
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = loginForm.querySelector('button[type="submit"]');
  button.disabled = true;
  showMessage('Проверяем учётные данные…');
  try {
    const result = await postJson('/api/auth/login', {
      username: document.getElementById('username').value,
      password: passwordInput.value,
    });
    passwordInput.value = '';
    loginForm.hidden = true;
    mfaStep.hidden = false;
    setupInstructions.hidden = result.stage !== 'setup';
    if (result.stage === 'setup') {
      document.getElementById('setupQr').src = result.qrDataUrl;
      document.getElementById('setupSecret').textContent = result.secret;
      document.getElementById('codeTitle').textContent = 'Подтвердите настройку';
      document.getElementById('codeHint').textContent = 'Введите шестизначный код, который показывает приложение. После проверки будут выданы одноразовые резервные коды.';
      document.querySelector('#verifyForm button').textContent = 'Подтвердить настройку';
    } else {
      document.getElementById('codeHint').textContent = 'Введите шестизначный код из приложения или один неиспользованный резервный код.';
    }
    document.getElementById('verificationCode').focus();
    showMessage(result.stage === 'setup' ? 'Привязка ещё не завершена — подтвердите код приложения.' : 'Введите код второго фактора.');
  } catch (error) {
    showMessage(error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

verifyForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = verifyForm.querySelector('button[type="submit"]');
  button.disabled = true;
  showMessage('Проверяем код…');
  try {
    const result = await postJson('/api/auth/verify', {
      code: document.getElementById('verificationCode').value,
    });
    if (Array.isArray(result.recoveryCodes)) {
      document.getElementById('recoveryCodes').textContent = result.recoveryCodes.join('\n');
      mfaStep.hidden = true;
      document.getElementById('recoveryStep').hidden = false;
      showMessage('Двухфакторная защита подключена.', 'success');
    } else {
      showMessage('Вход подтверждён. Открываем приложение…', 'success');
      window.location.replace('/');
    }
  } catch (error) {
    showMessage(error.message, 'error');
  } finally {
    button.disabled = false;
  }
});

checkExistingSession();
