import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const TOTP_PERIOD_SECONDS = 30;

export function randomTotpSecret() {
  const bytes = randomBytes(20);
  let bits = 0;
  let value = 0;
  let secret = '';
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      secret += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits) secret += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  return secret;
}

function decodeBase32(value) {
  let bits = 0;
  let buffer = 0;
  const bytes = [];
  for (const char of value.toUpperCase().replace(/=+$/, '')) {
    const digit = BASE32_ALPHABET.indexOf(char);
    if (digit < 0) throw new Error('Некорректный секрет TOTP.');
    buffer = (buffer << 5) | digit;
    bits += 5;
    if (bits >= 8) {
      bytes.push((buffer >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  if (!bytes.length) throw new Error('Пустой секрет TOTP.');
  return Buffer.from(bytes);
}

export function totpCode(secret, timestamp = Date.now()) {
  const counter = BigInt(Math.floor(timestamp / 1000 / TOTP_PERIOD_SECONDS));
  return generateHotp(secret, counter);
}

function generateHotp(secret, counter) {
  const message = Buffer.alloc(8);
  message.writeBigUInt64BE(counter);
  const digest = createHmac('sha1', decodeBase32(secret)).update(message).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binary = digest.readUInt32BE(offset) & 0x7fffffff;
  return String(binary % 1_000_000).padStart(6, '0');
}

export function matchingTotpCounter(secret, code, timestamp = Date.now()) {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code)) return null;
  const nowCounter = BigInt(Math.floor(timestamp / 1000 / TOTP_PERIOD_SECONDS));
  const candidate = Buffer.from(code);
  for (const offset of [-1n, 0n, 1n]) {
    const counter = nowCounter + offset;
    if (counter < 0n) continue;
    const expected = Buffer.from(generateHotp(secret, counter));
    if (candidate.length === expected.length && timingSafeEqual(candidate, expected)) return counter.toString();
  }
  return null;
}

export function verifyTotp(secret, code, timestamp = Date.now()) {
  return matchingTotpCounter(secret, code, timestamp) !== null;
}

export function hashPassword(password, salt = randomBytes(16)) {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) {
    throw new Error('Пароль должен содержать от 12 до 256 символов.');
  }
  return {
    salt: salt.toString('base64'),
    hash: scryptSync(password, salt, 64, { maxmem: 64 * 1024 * 1024 }).toString('base64'),
  };
}

export function verifyPassword(password, salt, expectedHash) {
  if (typeof password !== 'string' || password.length > 256) return false;
  const saltBytes = Buffer.from(salt, 'base64');
  const expected = Buffer.from(expectedHash, 'base64');
  if (saltBytes.length !== 16 || expected.length !== 64) return false;
  const actual = scryptSync(password, saltBytes, expected.length, { maxmem: 64 * 1024 * 1024 });
  return timingSafeEqual(actual, expected);
}

export function encryptTotpSecret(secret, key) {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()]);
  return {
    iv: iv.toString('base64'),
    ciphertext: ciphertext.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
  };
}

export function decryptTotpSecret(encrypted, key) {
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(encrypted.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(encrypted.tag, 'base64'));
  return Buffer.concat([
    decipher.update(Buffer.from(encrypted.ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8');
}

export function hashRecoveryCode(code) {
  return createHash('sha256').update(code).digest('hex');
}

export function createRecoveryCodes(count = 8) {
  const codes = Array.from({ length: count }, () => {
    const raw = randomBytes(8).toString('hex').toUpperCase();
    return `RADAR-${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}-${raw.slice(12)}`;
  });
  return { codes, hashes: codes.map((code) => hashRecoveryCode(code)) };
}

export function consumeRecoveryCode(code, hashes) {
  if (typeof code !== 'string' || typeof hashes?.length !== 'number') return -1;
  const candidate = Buffer.from(hashRecoveryCode(code.trim().toUpperCase()));
  let matchedIndex = -1;
  hashes.forEach((hash, index) => {
    const expected = Buffer.from(hash);
    if (candidate.length === expected.length && timingSafeEqual(candidate, expected)) matchedIndex = index;
  });
  return matchedIndex;
}

export function parseEncryptionKey(value) {
  const key = Buffer.from(value || '', 'base64');
  if (key.length !== 32) throw new Error('RADAR_ENCRYPTION_KEY должен быть Base64-кодировкой случайного ключа длиной 32 байта.');
  return key;
}
