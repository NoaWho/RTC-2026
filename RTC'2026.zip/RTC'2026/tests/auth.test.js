import test from 'node:test';
import assert from 'node:assert/strict';
import {
  consumeRecoveryCode,
  createRecoveryCodes,
  decryptTotpSecret,
  encryptTotpSecret,
  hashPassword,
  matchingTotpCounter,
  parseEncryptionKey,
  randomTotpSecret,
  verifyPassword,
  verifyTotp,
} from '../server/auth-core.js';

const RFC_TOTP_SECRET = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';

test('TOTP follows RFC 6238 six-digit SHA-1 vector and accepts only a short clock window', () => {
  const timestamp = 59_000;
  assert.equal(verifyTotp(RFC_TOTP_SECRET, '287082', timestamp), true);
  assert.equal(matchingTotpCounter(RFC_TOTP_SECRET, '287082', timestamp), '1');
  assert.equal(verifyTotp(RFC_TOTP_SECRET, '287083', timestamp), false);
  assert.equal(verifyTotp(RFC_TOTP_SECRET, '287082x', timestamp), false);
});

test('TOTP secrets are random base32 values suitable for enrollment', () => {
  const first = randomTotpSecret();
  const second = randomTotpSecret();
  assert.match(first, /^[A-Z2-7]{32}$/);
  assert.notEqual(first, second);
});

test('passwords are stored as salted scrypt hashes and verified without revealing mismatches', () => {
  const credentials = hashPassword('a-long-test-password');
  assert.notEqual(credentials.hash, 'a-long-test-password');
  assert.equal(verifyPassword('a-long-test-password', credentials.salt, credentials.hash), true);
  assert.equal(verifyPassword('incorrect-password', credentials.salt, credentials.hash), false);
});

test('TOTP secret encryption detects wrong keys and tampering', () => {
  const key = Buffer.alloc(32, 7);
  const encrypted = encryptTotpSecret(RFC_TOTP_SECRET, key);
  assert.equal(decryptTotpSecret(encrypted, key), RFC_TOTP_SECRET);
  assert.throws(() => decryptTotpSecret(encrypted, Buffer.alloc(32, 8)));
  assert.throws(() => decryptTotpSecret({ ...encrypted, ciphertext: Buffer.alloc(20).toString('base64') }, key));
});

test('recovery codes are unique, hashed, and match a single saved entry', () => {
  const { codes, hashes } = createRecoveryCodes();
  assert.equal(codes.length, 8);
  assert.equal(new Set(codes).size, codes.length);
  assert.ok(hashes.every((hash) => /^[a-f0-9]{64}$/.test(hash)));
  assert.equal(consumeRecoveryCode(codes[0].toLowerCase(), hashes), 0);
  assert.equal(consumeRecoveryCode('RADAR-0000-0000-0000-0000', hashes), -1);
});

test('encryption key must decode to exactly 32 bytes', () => {
  assert.equal(parseEncryptionKey(Buffer.alloc(32, 3).toString('base64')).length, 32);
  assert.throws(() => parseEncryptionKey('not-a-valid-key'));
});
