// Запуск: npm test
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

import {
  STATUS, validateCompany, validateDataset, JsonDataProvider, CsvDataProvider,
  OsmMapDataProvider, buildOsmMapUrl, getCompanyBusinessType, getRussianBusinessType,
  normalizeOsmElements, splitOsmBounds, isWithinOsmCircle,
  OSM_MIN_ZOOM, parseCsv, hasCoords,
} from '../public/js/data.js';
import {
  DEFAULT_FILTERS, applyFilters, computeKpi, computeRegionOpportunities, countBy,
  countStatuses, regionsByPotential, sortCompanies, validateFilters, parseNumberInput, getFilterOptions,
  UNKNOWN_STATUS,
} from '../public/js/filters.js';
import { buildCsv, sanitizeCell, escapeCsvField, csvFileName, CSV_COLUMNS } from '../public/js/export.js';
import { createStore } from '../public/js/state.js';

const raw = JSON.parse(await readFile(new URL('./fixtures/companies.json', import.meta.url), 'utf8'));
const { companies, warnings } = validateDataset(raw);
const osmCacheRaw = JSON.parse(await readFile(new URL('../public/data/osm-cache.json', import.meta.url), 'utf8'));

const company = (over = {}) => ({
  id: 'x1', name: 'Тест', region: 'Москва', industry: 'Логистика', clientStatus: STATUS.CLIENT,
  revenue: 100, growthRate: 5, latitude: 55.7, longitude: 37.6, description: '', ...over,
});

/* ---------- Данные ---------- */
test('демонстрационный файл: не менее 30 корректных записей без предупреждений', () => {
  assert.ok(companies.length >= 30);
  assert.equal(warnings.length, 0);
  assert.equal(companies.length, raw.companies.length);
});

test('демонстрационный файл: уникальные id, валидные координаты, разнообразие', () => {
  assert.equal(new Set(companies.map((c) => c.id)).size, companies.length);
  assert.ok(companies.every((c) => hasCoords(c) && Math.abs(c.latitude) <= 90 && Math.abs(c.longitude) <= 180));
  assert.ok(new Set(companies.map((c) => c.region)).size >= 5);
  assert.ok(new Set(companies.map((c) => c.industry)).size >= 5);
  const { potential, clients } = countStatuses(companies);
  assert.ok(potential >= 10 && clients >= 5);
  assert.equal(raw.meta.isDemo, true);
  assert.ok(companies.every((c) => c.description.startsWith('Демонстрационная запись')));
});

test('сохранённый срез OSM содержит реальные источниковые записи без неподтверждённых бизнес-фактов', () => {
  const { companies: cachedCompanies, meta } = validateDataset(osmCacheRaw);
  assert.equal(meta.isDemo, false);
  assert.equal(meta.dataset, 'OpenStreetMap (сохранённый срез)');
  assert.equal(cachedCompanies.length, 3);
  assert.ok(cachedCompanies.every((record) => record.dataSource === 'OpenStreetMap'));
  assert.ok(cachedCompanies.every((record) => record.sourceUrl.startsWith('https://www.openstreetmap.org/')));
  assert.ok(cachedCompanies.every((record) => record.clientStatus === null && record.revenue === null && record.growthRate === null));
});

test('validateCompany находит ошибки структуры', () => {
  assert.deepEqual(validateCompany(company()), []);
  assert.ok(validateCompany(null).length);
  assert.ok(validateCompany(company({ name: '' })).length);
  assert.ok(validateCompany(company({ clientStatus: 'Неизвестный' })).length);
  assert.ok(validateCompany(company({ revenue: -1 })).length);
  assert.ok(validateCompany(company({ revenue: '100' })).length);
  assert.ok(validateCompany(company({ growthRate: NaN })).length);
  assert.ok(validateCompany(company({ inn: '12345' })).length);
  assert.deepEqual(validateCompany(company({ inn: '7707083893' })), []);
  assert.ok(validateCompany(company({ latitude: 91 })).length);
  assert.ok(validateCompany(company({ longitude: 200 })).length);
  assert.ok(validateCompany(company({ longitude: null })).length, 'неполные координаты');
  assert.deepEqual(validateCompany(company({ latitude: null, longitude: null })), [], 'без координат допустимо');
});

test('финансовые показатели могут отсутствовать, но не могут быть некорректными', () => {
  assert.deepEqual(validateCompany(company({ revenue: null, growthRate: null })), []);
  assert.deepEqual(validateCompany(company({ revenue: undefined, growthRate: undefined })), []);
  assert.ok(validateCompany(company({ revenue: 'неизвестно' })).length);
  const result = validateDataset({ companies: [company({ revenue: null, growthRate: undefined })] });
  assert.equal(result.companies[0].revenue, null);
  assert.equal(result.companies[0].growthRate, null);
});

test('неподтверждённый статус и отсутствующие показатели не трактуются как факты или нули', () => {
  const unknown = company({ id: 'unknown', clientStatus: null, revenue: null, growthRate: null });
  const rows = [unknown, company({ id: 'known' })];
  assert.equal(applyFilters(rows, { ...DEFAULT_FILTERS, status: UNKNOWN_STATUS }).length, 1);
  assert.equal(applyFilters(rows, { ...DEFAULT_FILTERS, revenueMin: 0 }).length, 1);
  assert.deepEqual(countStatuses(rows), { clients: 1, potential: 0, unknown: 1 });
  assert.equal(computeKpi(rows).unknown, 1);
  assert.equal(sortCompanies(rows, { key: 'revenue', dir: 'desc' })[0].id, 'known');
  const opportunities = computeRegionOpportunities([
    unknown,
    company({ id: 'potential', clientStatus: STATUS.POTENTIAL, growthRate: null }),
  ]);
  assert.equal(opportunities[0].avgGrowth, null);
  assert.ok(Number.isFinite(opportunities[0].score));
});

test('validateDataset: пропускает плохие записи и дубликаты, бросает ошибку на неверной структуре', () => {
  const result = validateDataset({ companies: [company(), company(), company({ id: 'x2', name: '' }), company({ id: 'x3' })] });
  assert.deepEqual(result.companies.map((c) => c.id), ['x1', 'x3']);
  assert.equal(result.warnings.length, 2);
  assert.throws(() => validateDataset(null), /структура/);
  assert.throws(() => validateDataset({ companies: 'нет' }), /структура/);
  assert.throws(() => validateDataset({ companies: [{}] }), /ни одной корректной/);
});

test('JsonDataProvider: успех и обработка ошибок', async () => {
  const realFetch = globalThis.fetch;
  try {
    globalThis.fetch = async () => ({ ok: true, json: async () => raw });
    const ok = await new JsonDataProvider('x').load();
    assert.equal(ok.companies.length, companies.length);

    globalThis.fetch = async () => ({ ok: false, status: 404 });
    await assert.rejects(new JsonDataProvider('x').load(), /404/);

    globalThis.fetch = async () => ({ ok: true, json: async () => { throw new Error('bad'); } });
    await assert.rejects(new JsonDataProvider('x').load(), /JSON/);

    globalThis.fetch = async () => { throw new TypeError('network'); };
    await assert.rejects(new JsonDataProvider('x').load(), /npm start/);
  } finally {
    globalThis.fetch = realFetch;
  }
});

test('OsmMapDataProvider: ограничивает область и нормализует реальные объекты без выдуманного статуса клиента', async () => {
  const viewport = { south: 55.75, west: 37.6, north: 55.76, east: 37.61, zoom: OSM_MIN_ZOOM };
  const tag = (key, value) => ({ getAttribute: (name) => (name === 'k' ? key : name === 'v' ? value : null) });
  const element = (tagName, attrs, tags = {}, refs = []) => ({
    tagName,
    getAttribute: (name) => attrs[name] ?? null,
    querySelectorAll: (selector) => selector === ':scope > tag'
      ? Object.entries(tags).map(([key, value]) => tag(key, value))
      : selector === ':scope > nd'
        ? refs.map((ref) => ({ getAttribute: (name) => (name === 'ref' ? ref : null) }))
        : [],
  });
  const nodes = [
    element('node', { id: '42', lat: '55.75', lon: '37.61', timestamp: '2026-10-24T00:00:00Z' }, {
      name: 'Реальная кофейня',
      amenity: 'cafe',
      'addr:city': 'Москва',
      'addr:street': 'Тверская улица',
      'addr:housenumber': '1',
      operator: 'ООО Пример',
      'contact:website': 'https://example.org',
    }),
    element('node', { id: '46', lat: '55.76', lon: '37.62' }),
    element('node', { id: '44', lat: '55.75', lon: '37.61' }, { name: 'Не предприятие', amenity: 'theatre' }),
    element('node', { id: '45', lat: '55.75', lon: '37.61' }, { amenity: 'cafe' }),
    element('way', { id: '43', timestamp: '2026-10-24T00:00:00Z' }, { name: 'Реальная организация', office: 'company' }, ['42', '46']),
  ];
  let requestedUrl = '';
  const provider = new OsmMapDataProvider(viewport, {
    fetchImpl: async (url, options) => {
      requestedUrl = url;
      assert.equal(options.headers.Accept, 'application/xml');
      return { ok: true, text: async () => '<osm/>' };
    },
    parseXml: (text) => {
      assert.equal(text, '<osm/>');
      return {
        querySelector: () => null,
        querySelectorAll: () => nodes,
      };
    },
  });
  const result = await provider.load();
  assert.equal(requestedUrl, buildOsmMapUrl(viewport));
  assert.match(requestedUrl, /^https:\/\/api\.openstreetmap\.org\/api\/0\.6\/map\?bbox=/);
  assert.equal(result.companies.length, 2);
  assert.equal(result.companies[0].name, 'Реальная кофейня');
  assert.equal(result.companies[0].locality, 'Москва');
  assert.equal(result.companies[0].address, 'Тверская улица, 1, Москва');
  assert.equal(result.companies[0].website, 'https://example.org');
  assert.equal(result.companies[0].email, null);
  assert.equal(result.companies[0].osmTags.operator, 'ООО Пример');
  assert.equal(result.companies[0].sourceUrl, 'https://www.openstreetmap.org/node/42');
  assert.equal(result.companies[0].clientStatus, null);
  assert.equal(result.companies[0].revenue, null);
  assert.equal(result.companies[0].growthRate, null);
  assert.ok(Math.abs(result.companies[1].latitude - 55.755) < 1e-9);
  assert.ok(Math.abs(result.companies[1].longitude - 37.615) < 1e-9);
  assert.equal(result.companies[0].businessStatus, 'Сервис / общепит');
  assert.equal(result.companies[0].businessCategory, 'amenity');
  assert.equal(result.companies[0].businessType, 'Кафе');
  assert.equal(result.companies[0].businessIcon, 'food');
  assert.equal(result.meta.isDemo, false);
  assert.equal(result.meta.dataDate, null);
  assert.match(result.meta.checkedAt, /^\d{4}-\d{2}-\d{2}T/);
  assert.match(buildCsv(result.companies), /Дополнительные теги OSM/);
  const circleResult = await new OsmMapDataProvider(viewport, {
    circle: { center: { latitude: 55.75, longitude: 37.61 }, radius: 100 },
    fetchImpl: async () => ({ ok: true, text: async () => '<osm/>' }),
    parseXml: () => ({ querySelector: () => null, querySelectorAll: () => nodes }),
  }).load();
  assert.deepEqual(circleResult.companies.map((item) => item.id), ['osm-node-42']);
});

test('OSM-нормализация: адреса, типы и только именованные коммерческие объекты', () => {
  const result = normalizeOsmElements([
    { type: 'node', id: '1', lat: 55.75, lon: 37.61, tags: { name: 'Магазин', shop: 'supermarket' } },
    { type: 'node', id: '2', lat: 55.75, lon: 37.61, tags: { name: 'Театр', amenity: 'theatre' } },
    { type: 'node', id: '3', lat: 55.75, lon: 37.61, tags: { shop: 'bakery' } },
    { type: 'node', id: '4', lat: 55.75, lon: 37.61, tags: { name: 'Маркет', shop: 'supermarket', amenity: 'restaurant' } },
    { type: 'node', id: '5', lat: 55.75, lon: 37.61, tags: { name: 'Одежда', shop: 'clothes' } },
  ]);
  assert.equal(result.length, 3);
  assert.equal(result[0].businessStatus, 'Торговля');
  assert.equal(result[0].businessCategory, 'shop');
  assert.equal(result[0].businessType, 'Супермаркет');
  assert.equal(result[0].businessIcon, 'supermarket');
  assert.equal(result[1].businessType, 'Супермаркет');
  assert.equal(result[2].businessIcon, 'clothes');
  assert.equal(result[0].clientStatus, null);
});

test('тип объекта всегда отображается на русском, включая неизвестные категории OSM', () => {
  assert.equal(getRussianBusinessType('shop', 'tea'), 'Магазин чая');
  assert.equal(getRussianBusinessType('office', 'unknown_office'), 'Офис / организация');
  assert.equal(getRussianBusinessType('industrial', null), 'Производственный объект');
  assert.equal(getRussianBusinessType(null, null), 'Тип объекта не указан');
  assert.equal(getCompanyBusinessType({ osmTags: { amenity: 'cafe', shop: 'tea' } }), 'Кафе');
});

test('радиус выбора включает объекты внутри круга и исключает точки снаружи', () => {
  const circle = { center: { latitude: 47.222, longitude: 39.72 }, radius: 1000 };
  assert.equal(isWithinOsmCircle({ latitude: 47.222, longitude: 39.72 }, circle), true);
  assert.equal(isWithinOsmCircle({ latitude: 47.23, longitude: 39.72 }, circle), true);
  assert.equal(isWithinOsmCircle({ latitude: 47.25, longitude: 39.72 }, circle), false);
});

test('OSM map URL: ограничивает масштаб и размер запроса', () => {
  const tooFar = { south: 55.7, west: 37.5, north: 55.8, east: 37.7, zoom: OSM_MIN_ZOOM - 1 };
  assert.throws(() => buildOsmMapUrl(tooFar), /Приблизьте карту/);
  assert.throws(() => buildOsmMapUrl({ ...tooFar, zoom: OSM_MIN_ZOOM, east: 38.1 }), /слишком большая/);
  assert.equal(
    buildOsmMapUrl({ south: 55.75, west: 37.6, north: 55.76, east: 37.62, zoom: OSM_MIN_ZOOM }),
    'https://api.openstreetmap.org/api/0.6/map?bbox=37.6,55.75,37.62,55.76',
  );
  const tiles = splitOsmBounds({ south: 55.75, west: 37.6, north: 55.76, east: 37.628, zoom: OSM_MIN_ZOOM });
  assert.equal(tiles.length, 3);
  assert.ok(tiles.every((tile) => tile.east - tile.west <= 0.01));
  assert.equal(tiles[0].west, 37.6);
  assert.equal(tiles.at(-1).east, 37.628);
});

test('OSM provider делит область повторно, если API достиг лимита узлов', async () => {
  let requestCount = 0;
  const result = await new OsmMapDataProvider(
    { south: 55.75, west: 37.6, north: 55.76, east: 37.61, zoom: OSM_MIN_ZOOM },
    {
      fetchImpl: async () => {
        requestCount += 1;
        return requestCount === 1
          ? { ok: false, status: 400, text: async () => 'You requested too many nodes (limit is 50000).' }
          : { ok: true, text: async () => '<osm/>' };
      },
      parseXml: () => ({ querySelector: () => null, querySelectorAll: () => [] }),
    },
  ).load();
  assert.equal(requestCount, 3);
  assert.deepEqual(result.companies, []);
});

test('CSV parser: разделители, экранированные кавычки, BOM и многострочные поля', () => {
  assert.deepEqual(parseCsv('\uFEFFa;b\r\n"x;y";"строка 1\nстрока 2"'), [
    ['a', 'b'], ['x;y', 'строка 1\nстрока 2'],
  ]);
  assert.deepEqual(parseCsv('a,b\n"сказал ""да""",2'), [['a', 'b'], ['сказал "да"', '2']]);
  assert.throws(() => parseCsv('a;b\n"нет конца'), /незакрытую кавычку/);
});

test('CsvDataProvider: пустые сведения остаются неизвестными, внешняя запись не получает клиентский статус', async () => {
  const content = [
    'ИНН;Наименование;Регион;Основной ОКВЭД;Статус;Проверка статуса;Выручка, млн ₽;Темп роста, %;Широта;Долгота',
    '7700000000;ООО "Пример";Москва;Логистика;Действующий клиент;;12,5;;;;',
  ].join('\r\n');
  const provider = new CsvDataProvider({ name: 'registry.csv', text: async () => content });
  const result = await provider.load();
  assert.equal(result.companies.length, 1);
  assert.equal(result.companies[0].clientStatus, null);
  assert.equal(result.companies[0].revenue, 12.5);
  assert.equal(result.companies[0].growthRate, null);
  assert.equal(result.companies[0].latitude, null);
  assert.equal(result.companies[0].isDemo, false);
  assert.equal(result.meta.dataDate, null);
  assert.match(result.companies[0].dataSource, /registry\.csv/);
  assert.ok(result.warnings.some((warning) => warning.includes('источник проверки')));
});

test('CsvDataProvider: принимает ИНН и статус только с указанным источником проверки', async () => {
  const content = [
    'ID;ИНН;Наименование;Статус;Проверка статуса',
    'company-1;7707083893;ПАО Ростелеком;Действующий клиент;Выгрузка CRM от 2026-10-24',
  ].join('\r\n');
  const result = await new CsvDataProvider({ name: 'crm.csv', text: async () => content }).load();
  assert.equal(result.companies[0].id, 'company-1');
  assert.equal(result.companies[0].inn, '7707083893');
  assert.equal(result.companies[0].clientStatus, STATUS.CLIENT);
  assert.equal(result.companies[0].statusVerification, 'Выгрузка CRM от 2026-10-24');
});

test('CsvDataProvider: загружает реквизиты и источник открытых данных ФНС', async () => {
  const content = [
    'ИНН;ОГРН;Наименование;Организационно-правовая форма;Основной ОКВЭД;Руководитель;Адрес регистрации;Ссылка ФНС',
    '7707083893;1027700132195;ПАО Пример;Публичное акционерное общество;62.01;Иванов Иван Иванович;Москва, ул. Примерная, 1;https://egrul.nalog.ru/index.html',
  ].join('\r\n');
  const result = await new CsvDataProvider({ name: 'fns.csv', text: async () => content }).load();
  assert.equal(result.companies[0].inn, '7707083893');
  assert.equal(result.companies[0].ogrn, '1027700132195');
  assert.equal(result.companies[0].legalForm, 'Публичное акционерное общество');
  assert.equal(result.companies[0].okved, '62.01');
  assert.equal(result.companies[0].directorName, 'Иванов Иван Иванович');
  assert.equal(result.companies[0].registrationAddress, 'Москва, ул. Примерная, 1');
  assert.equal(result.companies[0].fnsSourceUrl, 'https://egrul.nalog.ru/index.html');
  assert.equal(result.companies[0].clientStatus, null);
  assert.match(buildCsv(result.companies), /ОГРН \/ ОГРНИП;Организационно-правовая форма;Основной ОКВЭД;Руководитель;Адрес регистрации по ФНС;URL источника ФНС/);
});

test('CSV-экспорт демо-набора можно импортировать с сохранением метки и статуса', async () => {
  const source = companies.slice(0, 1);
  const content = buildCsv(source);
  const result = await new CsvDataProvider({ name: 'demo.csv', text: async () => content }).load();
  assert.equal(result.companies[0].isDemo, true);
  assert.equal(result.companies[0].clientStatus, source[0].clientStatus);
});

/* ---------- Фильтры ---------- */
test('пустые фильтры возвращают все записи (сброс фильтров)', () => {
  assert.equal(applyFilters(companies, DEFAULT_FILTERS).length, companies.length);
  const dirty = { ...DEFAULT_FILTERS, region: 'Москва', search: 'абв' };
  assert.equal(applyFilters(companies, { ...DEFAULT_FILTERS }).length, companies.length);
  assert.ok(applyFilters(companies, dirty).length < companies.length);
});

test('фильтры по региону, отрасли и статусу', () => {
  const msk = applyFilters(companies, { ...DEFAULT_FILTERS, region: 'Москва' });
  assert.ok(msk.length > 0 && msk.every((c) => c.region === 'Москва'));
  const it = applyFilters(companies, { ...DEFAULT_FILTERS, industry: 'Информационные технологии' });
  assert.ok(it.length > 0 && it.every((c) => c.industry === 'Информационные технологии'));
  const pot = applyFilters(companies, { ...DEFAULT_FILTERS, status: STATUS.POTENTIAL });
  assert.ok(pot.length > 0 && pot.every((c) => c.clientStatus === STATUS.POTENTIAL));
});

test('тип OSM фильтруется отдельно от неизвестного статуса отношений с Ростелекомом', () => {
  const objects = [
    company({ id: 'shop', clientStatus: null, businessStatus: 'Торговля', businessCategory: 'shop' }),
    company({ id: 'office', clientStatus: null, businessStatus: 'Офис / организация', businessCategory: 'office' }),
  ];
  assert.deepEqual(
    applyFilters(objects, { ...DEFAULT_FILTERS, status: 'Торговля' }).map((item) => item.id),
    ['shop'],
  );
  assert.equal(applyFilters(objects, { ...DEFAULT_FILTERS, status: UNKNOWN_STATUS }).length, 2);
  const options = getFilterOptions(objects);
  assert.ok(options.statuses.includes('Торговля'));
  assert.ok(options.statuses.includes('Офис / организация'));
  assert.ok(options.statuses.includes(UNKNOWN_STATUS));
});

test('комбинированная фильтрация: регион + отрасль + потенциальный статус', () => {
  const f = { ...DEFAULT_FILTERS, region: 'Москва', industry: 'Информационные технологии', status: STATUS.POTENTIAL };
  const res = applyFilters(companies, f);
  assert.deepEqual(res.map((c) => c.id), ['demo-004']);
  const expected = companies.filter((c) => c.region === 'Москва' && c.industry === 'Информационные технологии' && c.clientStatus === STATUS.POTENTIAL);
  assert.deepEqual(res, expected);
});

test('диапазоны выручки и темпа роста включают границы', () => {
  const rev = applyFilters(companies, { ...DEFAULT_FILTERS, revenueMin: 1000, revenueMax: 2000 });
  assert.ok(rev.length > 0 && rev.every((c) => c.revenue >= 1000 && c.revenue <= 2000));
  const g = applyFilters(companies, { ...DEFAULT_FILTERS, growthMin: 20 });
  assert.ok(g.length > 0 && g.every((c) => c.growthRate >= 20));
  const edge = applyFilters([company({ revenue: 1000 })], { ...DEFAULT_FILTERS, revenueMin: 1000, revenueMax: 1000 });
  assert.equal(edge.length, 1);
});

test('поиск по названию: регистр, ё/е, пробелы', () => {
  assert.equal(applyFilters(companies, { ...DEFAULT_FILTERS, search: '  логист ' }).length, 3);
  assert.equal(applyFilters(companies, { ...DEFAULT_FILTERS, search: 'ЛОГИСТИК' }).length, 2);
  assert.equal(applyFilters([company({ name: 'Ёлка' })], { ...DEFAULT_FILTERS, search: 'елка' }).length, 1);
  assert.equal(applyFilters(companies, { ...DEFAULT_FILTERS, search: 'такой компании нет' }).length, 0);
});

test('validateFilters и parseNumberInput', () => {
  assert.equal(validateFilters(DEFAULT_FILTERS), '');
  assert.match(validateFilters({ ...DEFAULT_FILTERS, revenueMin: 10, revenueMax: 5 }), /Выручка/);
  assert.match(validateFilters({ ...DEFAULT_FILTERS, growthMin: 10, growthMax: 5 }), /роста/);
  assert.equal(applyFilters(companies, { ...DEFAULT_FILTERS, revenueMin: 10, revenueMax: 5 }).length, 0);
  assert.equal(parseNumberInput(''), null);
  assert.equal(parseNumberInput(' 12,5 '), 12.5);
  assert.equal(parseNumberInput('abc'), null);
  assert.equal(parseNumberInput('0'), 0);
});

test('пустая выборка: KPI равны нулю, графики и рейтинг пусты', () => {
  const empty = applyFilters(companies, { ...DEFAULT_FILTERS, search: 'zzz' });
  assert.deepEqual(computeKpi(empty), { total: 0, clients: 0, potential: 0, unknown: 0, territories: 0 });
  assert.deepEqual(countBy(empty, 'industry'), []);
  assert.deepEqual(regionsByPotential(empty), []);
  assert.deepEqual(computeRegionOpportunities(empty), []);
  assert.equal(buildCsv(empty).split('\r\n').filter(Boolean).length, 1, 'только заголовок');
});

/* ---------- KPI и согласованность ---------- */
test('KPI считаются по текущей выборке', () => {
  const all = computeKpi(companies);
  assert.equal(all.total, companies.length);
  assert.equal(all.clients + all.potential, all.total);
  const pot = applyFilters(companies, { ...DEFAULT_FILTERS, status: STATUS.POTENTIAL });
  const kpi = computeKpi(pot);
  assert.equal(kpi.clients, 0);
  assert.equal(kpi.potential, pot.length);
  const msk = computeKpi(applyFilters(companies, { ...DEFAULT_FILTERS, region: 'Москва' }));
  assert.equal(msk.total, 5);
  assert.ok(msk.territories <= 1);
});

test('графики, таблица и KPI согласованы на одной выборке', () => {
  const filters = [
    DEFAULT_FILTERS,
    { ...DEFAULT_FILTERS, status: STATUS.POTENTIAL },
    { ...DEFAULT_FILTERS, region: 'Республика Татарстан' },
    { ...DEFAULT_FILTERS, revenueMin: 1500, growthMin: 5 },
  ];
  for (const f of filters) {
    const rows = applyFilters(companies, f);
    const sum = (arr) => arr.reduce((s, x) => s + x.count, 0);
    assert.equal(sum(countBy(rows, 'industry')), rows.length);
    assert.equal(sum(countBy(rows, 'region')), rows.length);
    const st = countStatuses(rows);
    assert.equal(st.clients + st.potential, rows.length);
    assert.equal(sum(regionsByPotential(rows)), st.potential);
    assert.equal(computeKpi(rows).total, rows.length);
    assert.equal(computeRegionOpportunities(rows).reduce((s, r) => s + r.potential, 0), st.potential);
  }
});

/* ---------- Оценка территорий ---------- */
test('оценка территорий: диапазон 0–100, порядок, метки', () => {
  const rows = computeRegionOpportunities(companies);
  assert.ok(rows.length > 0);
  assert.ok(rows.every((r) => r.score >= 0 && r.score <= 100 && Number.isInteger(r.score)));
  for (let i = 1; i < rows.length; i += 1) assert.ok(rows[i - 1].score >= rows[i].score);
  assert.ok(rows.every((r) => r.potential > 0));
  assert.equal(Math.max(...rows.map((r) => r.score)) > 0, true);
});

test('оценка территорий: расчёт на малом примере', () => {
  const set = [
    company({ id: 'a1', region: 'А', clientStatus: STATUS.POTENTIAL, growthRate: 20, industry: 'И1' }),
    company({ id: 'a2', region: 'А', clientStatus: STATUS.POTENTIAL, growthRate: 20, industry: 'И2' }),
    company({ id: 'b1', region: 'Б', clientStatus: STATUS.POTENTIAL, growthRate: 10, industry: 'И1' }),
    company({ id: 'b2', region: 'Б', clientStatus: STATUS.CLIENT }),
    company({ id: 'b3', region: 'Б', clientStatus: STATUS.CLIENT }),
    company({ id: 'c1', region: 'В', clientStatus: STATUS.CLIENT }),
  ];
  const rows = computeRegionOpportunities(set);
  assert.deepEqual(rows.map((r) => r.region), ['А', 'Б']);
  assert.equal(rows[0].score, 100); // максимум по всем трём показателям
  // Б: 0.5*(1/2) + 0.3*(10/20) + 0.2*(1/2) = 0.5 -> 50
  assert.equal(rows[1].score, 50);
  assert.equal(rows[0].isOpportunity, true);
  assert.equal(rows[1].isOpportunity, false);
  assert.equal(rows[0].lowPresence, true);
  assert.equal(rows[1].lowPresence, false);
});

/* ---------- Сортировка ---------- */
test('сортировка по тексту и числам в обе стороны, исходный массив не меняется', () => {
  const copy = [...companies];
  const byRev = sortCompanies(companies, { key: 'revenue', dir: 'desc' });
  assert.deepEqual(companies, copy);
  for (let i = 1; i < byRev.length; i += 1) assert.ok(byRev[i - 1].revenue >= byRev[i].revenue);
  const byName = sortCompanies(companies, { key: 'name', dir: 'asc' });
  assert.equal(byName.length, companies.length);
  const byGrowth = sortCompanies(companies, { key: 'growthRate', dir: 'asc' });
  assert.ok(byGrowth[0].growthRate <= byGrowth[byGrowth.length - 1].growthRate);
});

test('getFilterOptions возвращает уникальные отсортированные значения', () => {
  const { regions, industries } = getFilterOptions(companies);
  assert.equal(new Set(regions).size, regions.length);
  assert.equal(new Set(industries).size, industries.length);
  assert.ok(regions.includes('Москва'));
});

/* ---------- CSV ---------- */
test('CSV: BOM, заголовки, число строк соответствует выборке', () => {
  const rows = applyFilters(companies, { ...DEFAULT_FILTERS, region: 'Москва', status: STATUS.POTENTIAL });
  const csv = buildCsv(rows);
  assert.ok(csv.startsWith('\uFEFF'));
  const lines = csv.slice(1).split('\r\n').filter(Boolean);
  assert.equal(lines.length, rows.length + 1);
  assert.equal(lines[0].split(';').length, CSV_COLUMNS.length);
  assert.ok(lines[0].includes('Название') && lines[0].includes('Выручка'));
  for (const c of rows) assert.ok(csv.includes(c.name));
  const others = companies.filter((c) => !rows.includes(c));
  for (const c of others) assert.ok(!csv.includes(c.name));
});

test('CSV: экранирование кавычек, разделителей и переводов строк', () => {
  assert.equal(escapeCsvField('a;b'), '"a;b"');
  assert.equal(escapeCsvField('он сказал "да"'), '"он сказал ""да"""');
  assert.equal(escapeCsvField('строка1\nстрока2'), '"строка1\nстрока2"');
  assert.equal(escapeCsvField('обычный'), 'обычный');
  const csv = buildCsv([company({ name: 'ООО "Ромашка"; филиал', description: 'a\nb' })]);
  assert.ok(csv.includes('"ООО ""Ромашка""; филиал"'));
});

test('CSV: защита от инъекций формул', () => {
  for (const bad of ['=SUM(A1)', '+1+1', '-2+3', '@cmd', '  =1+1', '\t=1', '\r=1']) {
    assert.ok(sanitizeCell(bad).startsWith("'"), `должно быть защищено: ${JSON.stringify(bad)}`);
  }
  assert.equal(sanitizeCell('Обычный текст'), 'Обычный текст');
  assert.equal(sanitizeCell(-3.5), '-3,5', 'числа не искажаются');
  assert.equal(sanitizeCell(12.5), '12,5');
  assert.equal(sanitizeCell(null), '');
  const csv = buildCsv([company({ name: '=HYPERLINK("http://x")' })]);
  assert.ok(csv.includes(`"'=HYPERLINK(""http://x"")"`));
});

test('CSV: имя файла и компании без координат', () => {
  assert.equal(csvFileName(7, new Date(2026, 9, 3)), 'radar4promote_2026-10-03_7-kompanij.csv');
  const csv = buildCsv([company({ latitude: null, longitude: null })]);
  const [headerLine, dataLine] = csv.slice(1).split('\r\n');
  const headers = headerLine.split(';');
  const values = dataLine.split(';');
  assert.equal(values[headers.indexOf('Широта')], '');
  assert.equal(values[headers.indexOf('Долгота')], '');
});

/* ---------- Состояние ---------- */
test('store: set, подписка и отписка', () => {
  const s = createStore({ a: 1, b: 2 });
  const seen = [];
  const off = s.subscribe((st) => seen.push(st.a));
  s.set({ a: 5 });
  s.set((st) => ({ a: st.a + 1 }));
  off();
  s.set({ a: 100 });
  assert.deepEqual(seen, [5, 6]);
  assert.equal(s.get().b, 2);
});
