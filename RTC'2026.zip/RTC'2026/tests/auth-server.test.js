import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHttpServer, prepareAuthServer } from '../server.js';
import { totpCode } from '../server/auth-core.js';

function cookieValue(response, name) {
  const cookie = response.headers.getSetCookie().find((value) => value.startsWith(`${name}=`));
  assert.ok(cookie, `Expected ${name} cookie`);
  return cookie.split(';', 1)[0];
}

test('server requires password and TOTP before serving the application', async () => {
  const tempDirectory = await mkdtemp(path.join(os.tmpdir(), 'radar-mfa-test-'));
  const envKeys = ['RADAR_ADMIN_USERNAME', 'RADAR_ADMIN_PASSWORD', 'RADAR_ENCRYPTION_KEY', 'RADAR_AUTH_FILE'];
  const previousEnv = new Map(envKeys.map((key) => [key, process.env[key]]));
  const username = 'test-admin';
  const password = 'Only-Test-Password-123!';
  process.env.RADAR_ADMIN_USERNAME = username;
  process.env.RADAR_ADMIN_PASSWORD = password;
  process.env.RADAR_ENCRYPTION_KEY = Buffer.alloc(32, 19).toString('base64');
  process.env.RADAR_AUTH_FILE = path.join(tempDirectory, 'auth.json');

  let server;
  try {
    await prepareAuthServer();
    server = createHttpServer();
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(0, '127.0.0.1', resolve);
    });
    const { port } = server.address();
    const origin = `http://127.0.0.1:${port}`;
    const request = (url, options = {}) => fetch(`${origin}${url}`, { redirect: 'manual', ...options });
    const post = (url, body, cookie, requestOrigin = origin) => request(url, {
      method: 'POST',
      headers: {
        Origin: requestOrigin,
        'Content-Type': 'application/json',
        ...(cookie ? { Cookie: cookie } : {}),
      },
      body: JSON.stringify(body),
    });

    const protectedPage = await request('/');
    assert.equal(protectedPage.status, 302);
    assert.equal(protectedPage.headers.get('location'), '/login.html');
    const loginPage = await request('/login.html');
    assert.equal(loginPage.status, 200);
    assert.match(await loginPage.text(), /вход паролем и кодом/);
    assert.equal((await request('/css/auth.css')).status, 200);
    assert.equal((await request('/assets/rostelecom-logo.png')).status, 200);
    assert.equal((await request('/js/app.js')).status, 401);
    assert.equal((await request('/js/../.radar-auth.json')).status, 401);
    assert.equal((await post('/api/auth/login', { username, password }, null, 'https://attacker.example')).status, 403);
    assert.equal((await post('/api/auth/login', null)).status, 400);

    const loginResponse = await post('/api/auth/login', { username, password });
    assert.equal(loginResponse.status, 200);
    const login = await loginResponse.json();
    assert.equal(login.stage, 'setup');
    assert.match(login.qrDataUrl, /^data:image\/png;base64,/);
    const challengeCookie = cookieValue(loginResponse, 'radar_challenge');
    assert.match(loginResponse.headers.getSetCookie().join(';'), /HttpOnly/);
    assert.match(loginResponse.headers.getSetCookie().join(';'), /SameSite=Strict/);

    const setupResponse = await post('/api/auth/verify', { code: totpCode(login.secret) }, challengeCookie);
    assert.equal(setupResponse.status, 200);
    const setup = await setupResponse.json();
    assert.equal(setup.authenticated, true);
    assert.equal(setup.recoveryCodes.length, 8);
    const sessionCookie = cookieValue(setupResponse, 'radar_session');
    assert.equal((await request('/api/auth/status', { headers: { Cookie: sessionCookie } })).status, 200);
    assert.equal((await request('/index.html', { headers: { Cookie: sessionCookie } })).status, 200);
    assert.equal((await request('/js/app.js', { headers: { Cookie: sessionCookie } })).status, 200);
    assert.equal((await request('/data/osm-cache.json', { headers: { Cookie: sessionCookie } })).status, 200);
    assert.equal((await request('/js/../.radar-auth.json', { headers: { Cookie: sessionCookie } })).status, 404);
    assert.equal((await request('/.radar-auth.json', { headers: { Cookie: sessionCookie } })).status, 404);

    const storedAuth = await readFile(process.env.RADAR_AUTH_FILE, 'utf8');
    assert.equal(storedAuth.includes(login.secret), false);
    assert.equal(storedAuth.includes(password), false);

    const replayLogin = await post('/api/auth/login', { username, password });
    const replayCookie = cookieValue(replayLogin, 'radar_challenge');
    const replayResponse = await post('/api/auth/verify', { code: totpCode(login.secret) }, replayCookie);
    assert.equal(replayResponse.status, 401);

    const recoveryResponse = await post('/api/auth/verify', { code: setup.recoveryCodes[0] }, replayCookie);
    assert.equal(recoveryResponse.status, 200);
    assert.equal((await recoveryResponse.json()).recoveryCodesRemaining, 7);

    const recoverySession = cookieValue(recoveryResponse, 'radar_session');
    const logoutResponse = await post('/api/auth/logout', {}, recoverySession);
    assert.equal(logoutResponse.status, 200);
    assert.deepEqual(await (await request('/api/auth/status')).json(), { authenticated: false });

    const rateLimitLogin = await post('/api/auth/login', { username, password });
    const rateLimitCookie = cookieValue(rateLimitLogin, 'radar_challenge');
    for (let attempt = 0; attempt < 6; attempt += 1) {
      assert.equal((await post('/api/auth/verify', { code: 'invalid' }, rateLimitCookie)).status, 401);
    }
    assert.equal((await post('/api/auth/verify', { code: 'invalid' }, rateLimitCookie)).status, 429);
  } finally {
    if (server) {
      server.closeAllConnections();
      await new Promise((resolve) => server.close(resolve));
    }
    for (const [key, value] of previousEnv) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
    await rm(tempDirectory, { recursive: true, force: true });
  }
});
